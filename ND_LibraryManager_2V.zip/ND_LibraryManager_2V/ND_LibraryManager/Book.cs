﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ND_LibraryManager
{
    public class Book : IBorrowable, IEquatable<Book>, IFormattable
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public DateTime PublishDate { get; set; }
        public int Quantity { get; set; }

        public ICollection<BorrowedBook> BorrowedBooks { get; set; }


        public Book() { }
        public Book(string title, string author, string isbn, DateTime publishDate, int quantity)
        {
            this.Title = title;
            this.Author = author;
            this.ISBN = isbn;
            this.PublishDate = publishDate;
            this.Quantity = quantity;           
        }

        public string ToString(string? format, IFormatProvider? formatProvider)
        {
            return format switch
            {
                "d" => $"{Title} by {Author}",
                "f" => $"{Title} - {Author}, ISBN: {ISBN}, Published on: {PublishDate.ToShortDateString()}, Quantity: {Quantity}",
                _ => $"{Title} by {Author}"
            };
        }

        public bool Equals(Book? other)
        {
            if (other == null) return false;
            return this.ISBN == other.ISBN;
        }
        public bool Borrow()
        {
            if (Quantity > 0)
            {
                Quantity--;
                return true;
            }
            return false;
        }

        public void Return()
        {
            Quantity++;
        }
    }
}
