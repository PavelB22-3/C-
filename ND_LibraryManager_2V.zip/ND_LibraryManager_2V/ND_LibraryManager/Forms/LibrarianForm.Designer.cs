﻿namespace ND_LibraryManager.Forms
{
    partial class LibrarianForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges41 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges42 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges43 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges44 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges45 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges46 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges47 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges48 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges49 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges50 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges51 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges52 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges53 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            librarianTabControl = new Guna.UI2.WinForms.Guna2TabControl();
            accountTab = new TabPage();
            idLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            addressLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            phoneLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            addressTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            phoneNumTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            emailLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            surnameLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            nameLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            saveButton = new Guna.UI2.WinForms.Guna2Button();
            birthDateTimePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            emailTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            surnameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            nameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            deleteAccButton = new Guna.UI2.WinForms.Guna2Button();
            changePassButton = new Guna.UI2.WinForms.Guna2Button();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            tabPage2 = new TabPage();
            updateBookButton = new Guna.UI2.WinForms.Guna2Button();
            deleteBookButton = new Guna.UI2.WinForms.Guna2Button();
            addBookButton = new Guna.UI2.WinForms.Guna2Button();
            quantityLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            publishDateLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            isbnLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            authorLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            titleLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            quantityNumericUpDown = new Guna.UI2.WinForms.Guna2NumericUpDown();
            publishedDateTimePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            ISBNTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            authorTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            titleTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            booksDataGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            studentTab = new TabPage();
            addStudentButton = new Guna.UI2.WinForms.Guna2Button();
            deleteStudentButton = new Guna.UI2.WinForms.Guna2Button();
            updateStudentButton = new Guna.UI2.WinForms.Guna2Button();
            birthDateLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            sBDateTimePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            sEmailTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            sSurnameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            sNameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            studentDataGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            closeButton = new Guna.UI2.WinForms.Guna2Button();
            guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(components);
            addLibrarianButton = new Guna.UI2.WinForms.Guna2Button();
            librarianTabControl.SuspendLayout();
            accountTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)quantityNumericUpDown).BeginInit();
            ((System.ComponentModel.ISupportInitialize)booksDataGridView).BeginInit();
            studentTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)studentDataGridView).BeginInit();
            SuspendLayout();
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 20;
            guna2Elipse1.TargetControl = this;
            // 
            // librarianTabControl
            // 
            librarianTabControl.Alignment = TabAlignment.Left;
            librarianTabControl.Controls.Add(accountTab);
            librarianTabControl.Controls.Add(tabPage2);
            librarianTabControl.Controls.Add(studentTab);
            librarianTabControl.Dock = DockStyle.Fill;
            librarianTabControl.ItemSize = new Size(180, 40);
            librarianTabControl.Location = new Point(0, 0);
            librarianTabControl.Name = "librarianTabControl";
            librarianTabControl.SelectedIndex = 0;
            librarianTabControl.Size = new Size(900, 500);
            librarianTabControl.TabButtonHoverState.BorderColor = Color.Empty;
            librarianTabControl.TabButtonHoverState.FillColor = Color.FromArgb(40, 52, 70);
            librarianTabControl.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 10F);
            librarianTabControl.TabButtonHoverState.ForeColor = Color.White;
            librarianTabControl.TabButtonHoverState.InnerColor = Color.FromArgb(40, 52, 70);
            librarianTabControl.TabButtonIdleState.BorderColor = Color.Empty;
            librarianTabControl.TabButtonIdleState.FillColor = Color.FromArgb(20, 49, 66);
            librarianTabControl.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 10F);
            librarianTabControl.TabButtonIdleState.ForeColor = Color.FromArgb(156, 160, 167);
            librarianTabControl.TabButtonIdleState.InnerColor = Color.FromArgb(33, 42, 57);
            librarianTabControl.TabButtonSelectedState.BorderColor = Color.Empty;
            librarianTabControl.TabButtonSelectedState.FillColor = Color.FromArgb(29, 27, 57);
            librarianTabControl.TabButtonSelectedState.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            librarianTabControl.TabButtonSelectedState.ForeColor = Color.White;
            librarianTabControl.TabButtonSelectedState.InnerColor = Color.FromArgb(76, 132, 255);
            librarianTabControl.TabButtonSize = new Size(180, 40);
            librarianTabControl.TabIndex = 0;
            librarianTabControl.TabMenuBackColor = Color.FromArgb(20, 49, 66);
            librarianTabControl.SelectedIndexChanged += TabIndexChanged;
            // 
            // accountTab
            // 
            accountTab.Controls.Add(addLibrarianButton);
            accountTab.Controls.Add(idLabel);
            accountTab.Controls.Add(addressLabel);
            accountTab.Controls.Add(phoneLabel);
            accountTab.Controls.Add(addressTextBox);
            accountTab.Controls.Add(phoneNumTextBox);
            accountTab.Controls.Add(emailLabel);
            accountTab.Controls.Add(surnameLabel);
            accountTab.Controls.Add(nameLabel);
            accountTab.Controls.Add(saveButton);
            accountTab.Controls.Add(birthDateTimePicker);
            accountTab.Controls.Add(emailTextBox);
            accountTab.Controls.Add(surnameTextBox);
            accountTab.Controls.Add(nameTextBox);
            accountTab.Controls.Add(deleteAccButton);
            accountTab.Controls.Add(changePassButton);
            accountTab.Controls.Add(guna2CirclePictureBox1);
            accountTab.Location = new Point(184, 4);
            accountTab.Name = "accountTab";
            accountTab.Padding = new Padding(3);
            accountTab.Size = new Size(712, 492);
            accountTab.TabIndex = 0;
            accountTab.Text = "Account";
            accountTab.UseVisualStyleBackColor = true;
            // 
            // idLabel
            // 
            idLabel.BackColor = Color.Transparent;
            idLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            idLabel.ForeColor = SystemColors.ControlDark;
            idLabel.Location = new Point(88, 160);
            idLabel.Name = "idLabel";
            idLabel.Size = new Size(17, 19);
            idLabel.TabIndex = 24;
            idLabel.Text = "ID";
            // 
            // addressLabel
            // 
            addressLabel.BackColor = Color.Transparent;
            addressLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addressLabel.ForeColor = SystemColors.ControlDark;
            addressLabel.Location = new Point(289, 344);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new Size(52, 19);
            addressLabel.TabIndex = 23;
            addressLabel.Text = "Address";
            // 
            // phoneLabel
            // 
            phoneLabel.BackColor = Color.Transparent;
            phoneLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            phoneLabel.ForeColor = SystemColors.ControlDark;
            phoneLabel.Location = new Point(289, 281);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new Size(96, 19);
            phoneLabel.TabIndex = 22;
            phoneLabel.Text = "Phone Number";
            // 
            // addressTextBox
            // 
            addressTextBox.AutoRoundedCorners = true;
            addressTextBox.BackColor = Color.Transparent;
            addressTextBox.BackgroundImageLayout = ImageLayout.None;
            addressTextBox.BorderColor = Color.Gray;
            addressTextBox.BorderRadius = 15;
            addressTextBox.BorderThickness = 2;
            addressTextBox.CustomizableEdges = customizableEdges5;
            addressTextBox.DefaultText = "";
            addressTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            addressTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            addressTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            addressTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            addressTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            addressTextBox.Font = new Font("Segoe UI", 9F);
            addressTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            addressTextBox.Location = new Point(289, 369);
            addressTextBox.Name = "addressTextBox";
            addressTextBox.PasswordChar = '\0';
            addressTextBox.PlaceholderText = "";
            addressTextBox.SelectedText = "";
            addressTextBox.ShadowDecoration.BorderRadius = 15;
            addressTextBox.ShadowDecoration.CustomizableEdges = customizableEdges6;
            addressTextBox.Size = new Size(258, 32);
            addressTextBox.TabIndex = 21;
            addressTextBox.TextChanged += UserInfoChanged;
            // 
            // phoneNumTextBox
            // 
            phoneNumTextBox.AutoRoundedCorners = true;
            phoneNumTextBox.BackColor = Color.Transparent;
            phoneNumTextBox.BackgroundImageLayout = ImageLayout.None;
            phoneNumTextBox.BorderColor = Color.Gray;
            phoneNumTextBox.BorderRadius = 15;
            phoneNumTextBox.BorderThickness = 2;
            phoneNumTextBox.CustomizableEdges = customizableEdges7;
            phoneNumTextBox.DefaultText = "";
            phoneNumTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            phoneNumTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            phoneNumTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            phoneNumTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            phoneNumTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            phoneNumTextBox.Font = new Font("Segoe UI", 9F);
            phoneNumTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            phoneNumTextBox.Location = new Point(289, 306);
            phoneNumTextBox.Name = "phoneNumTextBox";
            phoneNumTextBox.PasswordChar = '\0';
            phoneNumTextBox.PlaceholderText = "";
            phoneNumTextBox.SelectedText = "";
            phoneNumTextBox.ShadowDecoration.BorderRadius = 15;
            phoneNumTextBox.ShadowDecoration.CustomizableEdges = customizableEdges8;
            phoneNumTextBox.Size = new Size(258, 32);
            phoneNumTextBox.TabIndex = 20;
            phoneNumTextBox.TextChanged += UserInfoChanged;
            // 
            // emailLabel
            // 
            emailLabel.BackColor = Color.Transparent;
            emailLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailLabel.ForeColor = SystemColors.ControlDark;
            emailLabel.Location = new Point(289, 146);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new Size(37, 19);
            emailLabel.TabIndex = 19;
            emailLabel.Text = "Email";
            // 
            // surnameLabel
            // 
            surnameLabel.BackColor = Color.Transparent;
            surnameLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            surnameLabel.ForeColor = SystemColors.ControlDark;
            surnameLabel.Location = new Point(289, 83);
            surnameLabel.Name = "surnameLabel";
            surnameLabel.Size = new Size(57, 19);
            surnameLabel.TabIndex = 18;
            surnameLabel.Text = "Surname";
            // 
            // nameLabel
            // 
            nameLabel.BackColor = Color.Transparent;
            nameLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nameLabel.ForeColor = SystemColors.ControlDark;
            nameLabel.Location = new Point(289, 20);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(39, 19);
            nameLabel.TabIndex = 17;
            nameLabel.Text = "Name";
            // 
            // saveButton
            // 
            saveButton.BorderRadius = 25;
            saveButton.CustomizableEdges = customizableEdges9;
            saveButton.DisabledState.BorderColor = Color.DarkGray;
            saveButton.DisabledState.CustomBorderColor = Color.DarkGray;
            saveButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            saveButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            saveButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            saveButton.ForeColor = Color.White;
            saveButton.Location = new Point(558, 428);
            saveButton.Name = "saveButton";
            saveButton.ShadowDecoration.CustomizableEdges = customizableEdges10;
            saveButton.Size = new Size(146, 46);
            saveButton.TabIndex = 16;
            saveButton.Text = "Save Changes";
            saveButton.Click += saveButton_Click;
            // 
            // birthDateTimePicker
            // 
            birthDateTimePicker.BorderColor = Color.Gray;
            birthDateTimePicker.BorderRadius = 15;
            birthDateTimePicker.BorderThickness = 2;
            birthDateTimePicker.Checked = true;
            birthDateTimePicker.CustomizableEdges = customizableEdges11;
            birthDateTimePicker.FillColor = Color.FromArgb(224, 224, 224);
            birthDateTimePicker.Font = new Font("Segoe UI", 9F);
            birthDateTimePicker.Format = DateTimePickerFormat.Long;
            birthDateTimePicker.Location = new Point(289, 222);
            birthDateTimePicker.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            birthDateTimePicker.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            birthDateTimePicker.Name = "birthDateTimePicker";
            birthDateTimePicker.ShadowDecoration.CustomizableEdges = customizableEdges12;
            birthDateTimePicker.Size = new Size(258, 36);
            birthDateTimePicker.TabIndex = 15;
            birthDateTimePicker.Value = new DateTime(2024, 10, 14, 13, 40, 39, 405);
            birthDateTimePicker.TextChanged += UserInfoChanged;
            // 
            // emailTextBox
            // 
            emailTextBox.AutoRoundedCorners = true;
            emailTextBox.BackColor = Color.Transparent;
            emailTextBox.BackgroundImageLayout = ImageLayout.None;
            emailTextBox.BorderColor = Color.Gray;
            emailTextBox.BorderRadius = 15;
            emailTextBox.BorderThickness = 2;
            emailTextBox.CustomizableEdges = customizableEdges13;
            emailTextBox.DefaultText = "";
            emailTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            emailTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            emailTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            emailTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            emailTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            emailTextBox.Font = new Font("Segoe UI", 9F);
            emailTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            emailTextBox.Location = new Point(289, 171);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.PasswordChar = '\0';
            emailTextBox.PlaceholderText = "";
            emailTextBox.SelectedText = "";
            emailTextBox.ShadowDecoration.BorderRadius = 15;
            emailTextBox.ShadowDecoration.CustomizableEdges = customizableEdges14;
            emailTextBox.Size = new Size(258, 32);
            emailTextBox.TabIndex = 11;
            emailTextBox.TextChanged += UserInfoChanged;
            // 
            // surnameTextBox
            // 
            surnameTextBox.AutoRoundedCorners = true;
            surnameTextBox.BackColor = Color.Transparent;
            surnameTextBox.BackgroundImageLayout = ImageLayout.None;
            surnameTextBox.BorderColor = Color.Gray;
            surnameTextBox.BorderRadius = 15;
            surnameTextBox.BorderThickness = 2;
            surnameTextBox.CustomizableEdges = customizableEdges15;
            surnameTextBox.DefaultText = "";
            surnameTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            surnameTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            surnameTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            surnameTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            surnameTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            surnameTextBox.Font = new Font("Segoe UI", 9F);
            surnameTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            surnameTextBox.Location = new Point(289, 108);
            surnameTextBox.Name = "surnameTextBox";
            surnameTextBox.PasswordChar = '\0';
            surnameTextBox.PlaceholderText = "";
            surnameTextBox.SelectedText = "";
            surnameTextBox.ShadowDecoration.BorderRadius = 15;
            surnameTextBox.ShadowDecoration.CustomizableEdges = customizableEdges16;
            surnameTextBox.Size = new Size(258, 32);
            surnameTextBox.TabIndex = 10;
            surnameTextBox.TextChanged += UserInfoChanged;
            // 
            // nameTextBox
            // 
            nameTextBox.AutoRoundedCorners = true;
            nameTextBox.BackColor = Color.Transparent;
            nameTextBox.BackgroundImageLayout = ImageLayout.None;
            nameTextBox.BorderColor = Color.Gray;
            nameTextBox.BorderRadius = 15;
            nameTextBox.BorderThickness = 2;
            nameTextBox.CustomizableEdges = customizableEdges17;
            nameTextBox.DefaultText = "";
            nameTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            nameTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            nameTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            nameTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            nameTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            nameTextBox.Font = new Font("Segoe UI", 9F);
            nameTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            nameTextBox.Location = new Point(289, 45);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.PasswordChar = '\0';
            nameTextBox.PlaceholderText = "";
            nameTextBox.SelectedText = "";
            nameTextBox.ShadowDecoration.BorderRadius = 15;
            nameTextBox.ShadowDecoration.CustomizableEdges = customizableEdges18;
            nameTextBox.Size = new Size(258, 32);
            nameTextBox.TabIndex = 9;
            nameTextBox.TextChanged += UserInfoChanged;
            // 
            // deleteAccButton
            // 
            deleteAccButton.BorderRadius = 15;
            deleteAccButton.CustomizableEdges = customizableEdges19;
            deleteAccButton.DisabledState.BorderColor = Color.DarkGray;
            deleteAccButton.DisabledState.CustomBorderColor = Color.DarkGray;
            deleteAccButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            deleteAccButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            deleteAccButton.FillColor = Color.Red;
            deleteAccButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            deleteAccButton.ForeColor = Color.White;
            deleteAccButton.Location = new Point(35, 300);
            deleteAccButton.Name = "deleteAccButton";
            deleteAccButton.ShadowDecoration.CustomizableEdges = customizableEdges20;
            deleteAccButton.Size = new Size(146, 46);
            deleteAccButton.TabIndex = 2;
            deleteAccButton.Text = "Delete Account";
            deleteAccButton.Click += deleteAccButton_Click;
            // 
            // changePassButton
            // 
            changePassButton.BorderRadius = 15;
            changePassButton.CustomizableEdges = customizableEdges21;
            changePassButton.DisabledState.BorderColor = Color.DarkGray;
            changePassButton.DisabledState.CustomBorderColor = Color.DarkGray;
            changePassButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            changePassButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            changePassButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            changePassButton.ForeColor = Color.White;
            changePassButton.Location = new Point(35, 212);
            changePassButton.Name = "changePassButton";
            changePassButton.ShadowDecoration.CustomizableEdges = customizableEdges22;
            changePassButton.Size = new Size(146, 46);
            changePassButton.TabIndex = 1;
            changePassButton.Text = "Change Password";
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.Image = Properties.Resources.accIcon;
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(0, 0);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges23;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(205, 192);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2CirclePictureBox1.TabIndex = 0;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(updateBookButton);
            tabPage2.Controls.Add(deleteBookButton);
            tabPage2.Controls.Add(addBookButton);
            tabPage2.Controls.Add(quantityLabel);
            tabPage2.Controls.Add(publishDateLabel);
            tabPage2.Controls.Add(isbnLabel);
            tabPage2.Controls.Add(authorLabel);
            tabPage2.Controls.Add(titleLabel);
            tabPage2.Controls.Add(quantityNumericUpDown);
            tabPage2.Controls.Add(publishedDateTimePicker);
            tabPage2.Controls.Add(ISBNTextBox);
            tabPage2.Controls.Add(authorTextBox);
            tabPage2.Controls.Add(titleTextBox);
            tabPage2.Controls.Add(booksDataGridView);
            tabPage2.Location = new Point(184, 4);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(712, 492);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Manage Books";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // updateBookButton
            // 
            updateBookButton.BorderRadius = 20;
            updateBookButton.CustomizableEdges = customizableEdges24;
            updateBookButton.DisabledState.BorderColor = Color.DarkGray;
            updateBookButton.DisabledState.CustomBorderColor = Color.DarkGray;
            updateBookButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            updateBookButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            updateBookButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            updateBookButton.ForeColor = Color.White;
            updateBookButton.Location = new Point(605, 403);
            updateBookButton.Name = "updateBookButton";
            updateBookButton.ShadowDecoration.CustomizableEdges = customizableEdges25;
            updateBookButton.Size = new Size(99, 44);
            updateBookButton.TabIndex = 25;
            updateBookButton.Text = "Update";
            updateBookButton.Click += updateBookButton_Click;
            // 
            // deleteBookButton
            // 
            deleteBookButton.BorderRadius = 20;
            deleteBookButton.CustomizableEdges = customizableEdges26;
            deleteBookButton.DisabledState.BorderColor = Color.DarkGray;
            deleteBookButton.DisabledState.CustomBorderColor = Color.DarkGray;
            deleteBookButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            deleteBookButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            deleteBookButton.Enabled = false;
            deleteBookButton.FillColor = Color.FromArgb(192, 0, 0);
            deleteBookButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            deleteBookButton.ForeColor = Color.White;
            deleteBookButton.Location = new Point(42, 421);
            deleteBookButton.Name = "deleteBookButton";
            deleteBookButton.ShadowDecoration.CustomizableEdges = customizableEdges27;
            deleteBookButton.Size = new Size(99, 44);
            deleteBookButton.TabIndex = 24;
            deleteBookButton.Text = "Delete";
            deleteBookButton.Click += deleteBookButton_Click;
            // 
            // addBookButton
            // 
            addBookButton.BorderRadius = 20;
            addBookButton.CustomizableEdges = customizableEdges28;
            addBookButton.DisabledState.BorderColor = Color.DarkGray;
            addBookButton.DisabledState.CustomBorderColor = Color.DarkGray;
            addBookButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            addBookButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            addBookButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addBookButton.ForeColor = Color.White;
            addBookButton.Location = new Point(472, 403);
            addBookButton.Name = "addBookButton";
            addBookButton.ShadowDecoration.CustomizableEdges = customizableEdges29;
            addBookButton.Size = new Size(99, 44);
            addBookButton.TabIndex = 23;
            addBookButton.Text = "Add";
            addBookButton.Click += addBookButton_Click;
            // 
            // quantityLabel
            // 
            quantityLabel.BackColor = Color.Transparent;
            quantityLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            quantityLabel.ForeColor = SystemColors.ControlDark;
            quantityLabel.Location = new Point(470, 309);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new Size(57, 19);
            quantityLabel.TabIndex = 22;
            quantityLabel.Text = "Quantity";
            // 
            // publishDateLabel
            // 
            publishDateLabel.BackColor = Color.Transparent;
            publishDateLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            publishDateLabel.ForeColor = SystemColors.ControlDark;
            publishDateLabel.Location = new Point(470, 244);
            publishDateLabel.Name = "publishDateLabel";
            publishDateLabel.Size = new Size(64, 19);
            publishDateLabel.TabIndex = 21;
            publishDateLabel.Text = "Published";
            // 
            // isbnLabel
            // 
            isbnLabel.BackColor = Color.Transparent;
            isbnLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            isbnLabel.ForeColor = SystemColors.ControlDark;
            isbnLabel.Location = new Point(470, 180);
            isbnLabel.Name = "isbnLabel";
            isbnLabel.Size = new Size(32, 19);
            isbnLabel.TabIndex = 20;
            isbnLabel.Text = "ISBN";
            // 
            // authorLabel
            // 
            authorLabel.BackColor = Color.Transparent;
            authorLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            authorLabel.ForeColor = SystemColors.ControlDark;
            authorLabel.Location = new Point(470, 116);
            authorLabel.Name = "authorLabel";
            authorLabel.Size = new Size(46, 19);
            authorLabel.TabIndex = 19;
            authorLabel.Text = "Author";
            // 
            // titleLabel
            // 
            titleLabel.BackColor = Color.Transparent;
            titleLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            titleLabel.ForeColor = SystemColors.ControlDark;
            titleLabel.Location = new Point(470, 52);
            titleLabel.Name = "titleLabel";
            titleLabel.Size = new Size(31, 19);
            titleLabel.TabIndex = 18;
            titleLabel.Text = "Title";
            // 
            // quantityNumericUpDown
            // 
            quantityNumericUpDown.BackColor = Color.Transparent;
            quantityNumericUpDown.CustomizableEdges = customizableEdges30;
            quantityNumericUpDown.Font = new Font("Segoe UI", 9F);
            quantityNumericUpDown.Location = new Point(470, 334);
            quantityNumericUpDown.Name = "quantityNumericUpDown";
            quantityNumericUpDown.ShadowDecoration.CustomizableEdges = customizableEdges31;
            quantityNumericUpDown.Size = new Size(82, 37);
            quantityNumericUpDown.TabIndex = 6;
            // 
            // publishedDateTimePicker
            // 
            publishedDateTimePicker.BorderRadius = 15;
            publishedDateTimePicker.Checked = true;
            publishedDateTimePicker.CustomizableEdges = customizableEdges32;
            publishedDateTimePicker.FillColor = Color.FromArgb(224, 224, 224);
            publishedDateTimePicker.Font = new Font("Segoe UI", 9F);
            publishedDateTimePicker.Format = DateTimePickerFormat.Long;
            publishedDateTimePicker.Location = new Point(472, 269);
            publishedDateTimePicker.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            publishedDateTimePicker.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            publishedDateTimePicker.Name = "publishedDateTimePicker";
            publishedDateTimePicker.ShadowDecoration.CustomizableEdges = customizableEdges33;
            publishedDateTimePicker.Size = new Size(234, 34);
            publishedDateTimePicker.TabIndex = 5;
            publishedDateTimePicker.Value = new DateTime(2024, 10, 14, 21, 14, 50, 954);
            // 
            // ISBNTextBox
            // 
            ISBNTextBox.BackgroundImageLayout = ImageLayout.None;
            ISBNTextBox.BorderColor = Color.Silver;
            ISBNTextBox.BorderRadius = 15;
            ISBNTextBox.BorderThickness = 2;
            ISBNTextBox.CustomizableEdges = customizableEdges34;
            ISBNTextBox.DefaultText = "";
            ISBNTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            ISBNTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            ISBNTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            ISBNTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            ISBNTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            ISBNTextBox.Font = new Font("Segoe UI", 9F);
            ISBNTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            ISBNTextBox.Location = new Point(472, 205);
            ISBNTextBox.Name = "ISBNTextBox";
            ISBNTextBox.PasswordChar = '\0';
            ISBNTextBox.PlaceholderText = "";
            ISBNTextBox.SelectedText = "";
            ISBNTextBox.ShadowDecoration.CustomizableEdges = customizableEdges35;
            ISBNTextBox.Size = new Size(234, 33);
            ISBNTextBox.TabIndex = 3;
            // 
            // authorTextBox
            // 
            authorTextBox.BackgroundImageLayout = ImageLayout.None;
            authorTextBox.BorderColor = Color.Silver;
            authorTextBox.BorderRadius = 15;
            authorTextBox.BorderThickness = 2;
            authorTextBox.CustomizableEdges = customizableEdges36;
            authorTextBox.DefaultText = "";
            authorTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            authorTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            authorTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            authorTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            authorTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            authorTextBox.Font = new Font("Segoe UI", 9F);
            authorTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            authorTextBox.Location = new Point(470, 141);
            authorTextBox.Name = "authorTextBox";
            authorTextBox.PasswordChar = '\0';
            authorTextBox.PlaceholderText = "";
            authorTextBox.SelectedText = "";
            authorTextBox.ShadowDecoration.CustomizableEdges = customizableEdges37;
            authorTextBox.Size = new Size(234, 33);
            authorTextBox.TabIndex = 2;
            // 
            // titleTextBox
            // 
            titleTextBox.BackgroundImageLayout = ImageLayout.None;
            titleTextBox.BorderColor = Color.Silver;
            titleTextBox.BorderRadius = 15;
            titleTextBox.BorderThickness = 2;
            titleTextBox.CustomizableEdges = customizableEdges38;
            titleTextBox.DefaultText = "";
            titleTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            titleTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            titleTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            titleTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            titleTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            titleTextBox.Font = new Font("Segoe UI", 9F);
            titleTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            titleTextBox.Location = new Point(470, 77);
            titleTextBox.Name = "titleTextBox";
            titleTextBox.PasswordChar = '\0';
            titleTextBox.PlaceholderText = "";
            titleTextBox.SelectedText = "";
            titleTextBox.ShadowDecoration.CustomizableEdges = customizableEdges39;
            titleTextBox.Size = new Size(234, 33);
            titleTextBox.TabIndex = 1;
            // 
            // booksDataGridView
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            booksDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            booksDataGridView.BackgroundColor = Color.Silver;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            booksDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            booksDataGridView.ColumnHeadersHeight = 4;
            booksDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            booksDataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            booksDataGridView.GridColor = Color.FromArgb(231, 229, 255);
            booksDataGridView.Location = new Point(0, 8);
            booksDataGridView.Name = "booksDataGridView";
            booksDataGridView.RowHeadersVisible = false;
            booksDataGridView.Size = new Size(458, 389);
            booksDataGridView.TabIndex = 0;
            booksDataGridView.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            booksDataGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            booksDataGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            booksDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            booksDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            booksDataGridView.ThemeStyle.BackColor = Color.Silver;
            booksDataGridView.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            booksDataGridView.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            booksDataGridView.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            booksDataGridView.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            booksDataGridView.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            booksDataGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            booksDataGridView.ThemeStyle.HeaderStyle.Height = 4;
            booksDataGridView.ThemeStyle.ReadOnly = false;
            booksDataGridView.ThemeStyle.RowsStyle.BackColor = Color.White;
            booksDataGridView.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            booksDataGridView.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            booksDataGridView.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            booksDataGridView.ThemeStyle.RowsStyle.Height = 25;
            booksDataGridView.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            booksDataGridView.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            booksDataGridView.SelectionChanged += bookSelected;
            // 
            // studentTab
            // 
            studentTab.Controls.Add(addStudentButton);
            studentTab.Controls.Add(deleteStudentButton);
            studentTab.Controls.Add(updateStudentButton);
            studentTab.Controls.Add(birthDateLabel);
            studentTab.Controls.Add(guna2HtmlLabel3);
            studentTab.Controls.Add(guna2HtmlLabel2);
            studentTab.Controls.Add(guna2HtmlLabel1);
            studentTab.Controls.Add(sBDateTimePicker);
            studentTab.Controls.Add(sEmailTextBox);
            studentTab.Controls.Add(sSurnameTextBox);
            studentTab.Controls.Add(sNameTextBox);
            studentTab.Controls.Add(studentDataGridView);
            studentTab.Location = new Point(184, 4);
            studentTab.Name = "studentTab";
            studentTab.Padding = new Padding(3);
            studentTab.Size = new Size(712, 492);
            studentTab.TabIndex = 2;
            studentTab.Text = "Manage Students";
            studentTab.UseVisualStyleBackColor = true;
            // 
            // addStudentButton
            // 
            addStudentButton.BorderRadius = 20;
            addStudentButton.CustomizableEdges = customizableEdges40;
            addStudentButton.DisabledState.BorderColor = Color.DarkGray;
            addStudentButton.DisabledState.CustomBorderColor = Color.DarkGray;
            addStudentButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            addStudentButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            addStudentButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            addStudentButton.ForeColor = Color.White;
            addStudentButton.Location = new Point(467, 348);
            addStudentButton.Name = "addStudentButton";
            addStudentButton.ShadowDecoration.CustomizableEdges = customizableEdges41;
            addStudentButton.Size = new Size(99, 44);
            addStudentButton.TabIndex = 31;
            addStudentButton.Text = "Add";
            addStudentButton.Click += addStudentButton_Click;
            // 
            // deleteStudentButton
            // 
            deleteStudentButton.BorderRadius = 20;
            deleteStudentButton.CustomizableEdges = customizableEdges42;
            deleteStudentButton.DisabledState.BorderColor = Color.DarkGray;
            deleteStudentButton.DisabledState.CustomBorderColor = Color.DarkGray;
            deleteStudentButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            deleteStudentButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            deleteStudentButton.FillColor = Color.FromArgb(192, 0, 0);
            deleteStudentButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            deleteStudentButton.ForeColor = Color.White;
            deleteStudentButton.Location = new Point(21, 412);
            deleteStudentButton.Name = "deleteStudentButton";
            deleteStudentButton.ShadowDecoration.CustomizableEdges = customizableEdges43;
            deleteStudentButton.Size = new Size(99, 44);
            deleteStudentButton.TabIndex = 30;
            deleteStudentButton.Text = "Delete";
            deleteStudentButton.Click += deleteStudentButton_Click;
            // 
            // updateStudentButton
            // 
            updateStudentButton.BorderRadius = 20;
            updateStudentButton.CustomizableEdges = customizableEdges44;
            updateStudentButton.DisabledState.BorderColor = Color.DarkGray;
            updateStudentButton.DisabledState.CustomBorderColor = Color.DarkGray;
            updateStudentButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            updateStudentButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            updateStudentButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            updateStudentButton.ForeColor = Color.White;
            updateStudentButton.Location = new Point(602, 348);
            updateStudentButton.Name = "updateStudentButton";
            updateStudentButton.ShadowDecoration.CustomizableEdges = customizableEdges45;
            updateStudentButton.Size = new Size(99, 44);
            updateStudentButton.TabIndex = 29;
            updateStudentButton.Text = "Update";
            updateStudentButton.Click += updateStudentButton_Click;
            // 
            // birthDateLabel
            // 
            birthDateLabel.BackColor = Color.Transparent;
            birthDateLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            birthDateLabel.ForeColor = SystemColors.ControlDark;
            birthDateLabel.Location = new Point(467, 251);
            birthDateLabel.Name = "birthDateLabel";
            birthDateLabel.Size = new Size(66, 19);
            birthDateLabel.TabIndex = 27;
            birthDateLabel.Text = "Birth Date";
            // 
            // guna2HtmlLabel3
            // 
            guna2HtmlLabel3.BackColor = Color.Transparent;
            guna2HtmlLabel3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel3.ForeColor = SystemColors.ControlDark;
            guna2HtmlLabel3.Location = new Point(467, 186);
            guna2HtmlLabel3.Name = "guna2HtmlLabel3";
            guna2HtmlLabel3.Size = new Size(37, 19);
            guna2HtmlLabel3.TabIndex = 14;
            guna2HtmlLabel3.Text = "Email";
            // 
            // guna2HtmlLabel2
            // 
            guna2HtmlLabel2.BackColor = Color.Transparent;
            guna2HtmlLabel2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel2.ForeColor = SystemColors.ControlDark;
            guna2HtmlLabel2.Location = new Point(467, 122);
            guna2HtmlLabel2.Name = "guna2HtmlLabel2";
            guna2HtmlLabel2.Size = new Size(57, 19);
            guna2HtmlLabel2.TabIndex = 13;
            guna2HtmlLabel2.Text = "Surname";
            // 
            // guna2HtmlLabel1
            // 
            guna2HtmlLabel1.BackColor = Color.Transparent;
            guna2HtmlLabel1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2HtmlLabel1.ForeColor = SystemColors.ControlDark;
            guna2HtmlLabel1.Location = new Point(467, 58);
            guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            guna2HtmlLabel1.Size = new Size(39, 19);
            guna2HtmlLabel1.TabIndex = 12;
            guna2HtmlLabel1.Text = "Name";
            // 
            // sBDateTimePicker
            // 
            sBDateTimePicker.BorderRadius = 15;
            sBDateTimePicker.Checked = true;
            sBDateTimePicker.CustomizableEdges = customizableEdges46;
            sBDateTimePicker.FillColor = Color.FromArgb(224, 224, 224);
            sBDateTimePicker.Font = new Font("Segoe UI", 9F);
            sBDateTimePicker.Format = DateTimePickerFormat.Long;
            sBDateTimePicker.Location = new Point(467, 276);
            sBDateTimePicker.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            sBDateTimePicker.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            sBDateTimePicker.Name = "sBDateTimePicker";
            sBDateTimePicker.ShadowDecoration.CustomizableEdges = customizableEdges47;
            sBDateTimePicker.Size = new Size(234, 34);
            sBDateTimePicker.TabIndex = 6;
            sBDateTimePicker.Value = new DateTime(2024, 10, 14, 21, 14, 50, 954);
            // 
            // sEmailTextBox
            // 
            sEmailTextBox.BackgroundImageLayout = ImageLayout.None;
            sEmailTextBox.BorderColor = Color.Silver;
            sEmailTextBox.BorderRadius = 15;
            sEmailTextBox.BorderThickness = 2;
            sEmailTextBox.CustomizableEdges = customizableEdges48;
            sEmailTextBox.DefaultText = "";
            sEmailTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            sEmailTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            sEmailTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            sEmailTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            sEmailTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            sEmailTextBox.Font = new Font("Segoe UI", 9F);
            sEmailTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            sEmailTextBox.Location = new Point(467, 211);
            sEmailTextBox.Name = "sEmailTextBox";
            sEmailTextBox.PasswordChar = '\0';
            sEmailTextBox.PlaceholderText = "";
            sEmailTextBox.SelectedText = "";
            sEmailTextBox.ShadowDecoration.CustomizableEdges = customizableEdges49;
            sEmailTextBox.Size = new Size(234, 33);
            sEmailTextBox.TabIndex = 4;
            // 
            // sSurnameTextBox
            // 
            sSurnameTextBox.BackgroundImageLayout = ImageLayout.None;
            sSurnameTextBox.BorderColor = Color.Silver;
            sSurnameTextBox.BorderRadius = 15;
            sSurnameTextBox.BorderThickness = 2;
            sSurnameTextBox.CustomizableEdges = customizableEdges50;
            sSurnameTextBox.DefaultText = "";
            sSurnameTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            sSurnameTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            sSurnameTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            sSurnameTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            sSurnameTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            sSurnameTextBox.Font = new Font("Segoe UI", 9F);
            sSurnameTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            sSurnameTextBox.Location = new Point(467, 147);
            sSurnameTextBox.Name = "sSurnameTextBox";
            sSurnameTextBox.PasswordChar = '\0';
            sSurnameTextBox.PlaceholderText = "";
            sSurnameTextBox.SelectedText = "";
            sSurnameTextBox.ShadowDecoration.CustomizableEdges = customizableEdges51;
            sSurnameTextBox.Size = new Size(234, 33);
            sSurnameTextBox.TabIndex = 3;
            // 
            // sNameTextBox
            // 
            sNameTextBox.BackgroundImageLayout = ImageLayout.None;
            sNameTextBox.BorderColor = Color.Silver;
            sNameTextBox.BorderRadius = 15;
            sNameTextBox.BorderThickness = 2;
            sNameTextBox.CustomizableEdges = customizableEdges52;
            sNameTextBox.DefaultText = "";
            sNameTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            sNameTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            sNameTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            sNameTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            sNameTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            sNameTextBox.Font = new Font("Segoe UI", 9F);
            sNameTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            sNameTextBox.Location = new Point(467, 83);
            sNameTextBox.Name = "sNameTextBox";
            sNameTextBox.PasswordChar = '\0';
            sNameTextBox.PlaceholderText = "";
            sNameTextBox.SelectedText = "";
            sNameTextBox.ShadowDecoration.CustomizableEdges = customizableEdges53;
            sNameTextBox.Size = new Size(234, 33);
            sNameTextBox.TabIndex = 2;
            // 
            // studentDataGridView
            // 
            dataGridViewCellStyle4.BackColor = Color.White;
            studentDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            studentDataGridView.BackgroundColor = Color.Silver;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = Color.White;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            studentDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            studentDataGridView.ColumnHeadersHeight = 4;
            studentDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            studentDataGridView.DefaultCellStyle = dataGridViewCellStyle6;
            studentDataGridView.GridColor = Color.FromArgb(231, 229, 255);
            studentDataGridView.Location = new Point(3, 3);
            studentDataGridView.Name = "studentDataGridView";
            studentDataGridView.RowHeadersVisible = false;
            studentDataGridView.Size = new Size(458, 389);
            studentDataGridView.TabIndex = 1;
            studentDataGridView.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            studentDataGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            studentDataGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            studentDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            studentDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            studentDataGridView.ThemeStyle.BackColor = Color.Silver;
            studentDataGridView.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            studentDataGridView.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            studentDataGridView.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            studentDataGridView.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            studentDataGridView.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            studentDataGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            studentDataGridView.ThemeStyle.HeaderStyle.Height = 4;
            studentDataGridView.ThemeStyle.ReadOnly = false;
            studentDataGridView.ThemeStyle.RowsStyle.BackColor = Color.White;
            studentDataGridView.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            studentDataGridView.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            studentDataGridView.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            studentDataGridView.ThemeStyle.RowsStyle.Height = 25;
            studentDataGridView.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            studentDataGridView.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            studentDataGridView.SelectionChanged += studentSelected;
            // 
            // closeButton
            // 
            closeButton.BackColor = Color.White;
            closeButton.BorderRadius = 22;
            closeButton.CustomBorderColor = Color.Transparent;
            closeButton.CustomizableEdges = customizableEdges1;
            closeButton.DisabledState.BorderColor = Color.DarkGray;
            closeButton.DisabledState.CustomBorderColor = Color.DarkGray;
            closeButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            closeButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            closeButton.FillColor = Color.Red;
            closeButton.FocusedColor = Color.White;
            closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            closeButton.ForeColor = Color.White;
            closeButton.Location = new Point(844, 12);
            closeButton.Name = "closeButton";
            closeButton.ShadowDecoration.CustomizableEdges = customizableEdges2;
            closeButton.Size = new Size(44, 45);
            closeButton.TabIndex = 17;
            closeButton.Text = "X";
            closeButton.Click += closeButton_Click;
            // 
            // guna2DragControl1
            // 
            guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            guna2DragControl1.TargetControl = this;
            guna2DragControl1.UseTransparentDrag = true;
            // 
            // addLibrarianButton
            // 
            addLibrarianButton.BorderRadius = 10;
            addLibrarianButton.CustomizableEdges = customizableEdges3;
            addLibrarianButton.DisabledState.BorderColor = Color.DarkGray;
            addLibrarianButton.DisabledState.CustomBorderColor = Color.DarkGray;
            addLibrarianButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            addLibrarianButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            addLibrarianButton.FillColor = Color.CornflowerBlue;
            addLibrarianButton.Font = new Font("Segoe UI", 9F);
            addLibrarianButton.ForeColor = Color.White;
            addLibrarianButton.Location = new Point(35, 428);
            addLibrarianButton.Name = "addLibrarianButton";
            addLibrarianButton.ShadowDecoration.CustomizableEdges = customizableEdges4;
            addLibrarianButton.Size = new Size(146, 45);
            addLibrarianButton.TabIndex = 25;
            addLibrarianButton.Text = "Add Librarian";
            addLibrarianButton.Click += addLibrarianButton_Click;
            // 
            // LibrarianForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(900, 500);
            Controls.Add(closeButton);
            Controls.Add(librarianTabControl);
            FormBorderStyle = FormBorderStyle.None;
            Name = "LibrarianForm";
            Text = "LibrarianForm";
            FormClosing += LibrarianForm_FormClosing;
            librarianTabControl.ResumeLayout(false);
            accountTab.ResumeLayout(false);
            accountTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)quantityNumericUpDown).EndInit();
            ((System.ComponentModel.ISupportInitialize)booksDataGridView).EndInit();
            studentTab.ResumeLayout(false);
            studentTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)studentDataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2TabControl librarianTabControl;
        private TabPage accountTab;
        private TabPage tabPage2;
        private TabPage studentTab;
        protected Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2Button changePassButton;
        private Guna.UI2.WinForms.Guna2Button deleteAccButton;
        private Guna.UI2.WinForms.Guna2TextBox nameTextBox;
        private Guna.UI2.WinForms.Guna2TextBox surnameTextBox;
        private Guna.UI2.WinForms.Guna2TextBox emailTextBox;
        private Guna.UI2.WinForms.Guna2DateTimePicker birthDateTimePicker;
        private Guna.UI2.WinForms.Guna2Button saveButton;
        private Guna.UI2.WinForms.Guna2HtmlLabel nameLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel surnameLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel emailLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel addressLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel phoneLabel;
        private Guna.UI2.WinForms.Guna2TextBox addressTextBox;
        private Guna.UI2.WinForms.Guna2TextBox phoneNumTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel idLabel;
        private Guna.UI2.WinForms.Guna2Button closeButton;
        private Guna.UI2.WinForms.Guna2DataGridView booksDataGridView;
        private Guna.UI2.WinForms.Guna2TextBox titleTextBox;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox4;
        private Guna.UI2.WinForms.Guna2TextBox ISBNTextBox;
        private Guna.UI2.WinForms.Guna2TextBox authorTextBox;
        private Guna.UI2.WinForms.Guna2DateTimePicker publishedDateTimePicker;
        private Guna.UI2.WinForms.Guna2NumericUpDown quantityNumericUpDown;
        private Guna.UI2.WinForms.Guna2HtmlLabel titleLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel publishDateLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel isbnLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel authorLabel;
        private Guna.UI2.WinForms.Guna2Button updateBookButton;
        private Guna.UI2.WinForms.Guna2Button deleteBookButton;
        private Guna.UI2.WinForms.Guna2Button addBookButton;
        private Guna.UI2.WinForms.Guna2HtmlLabel quantityLabel;
        private Guna.UI2.WinForms.Guna2TextBox sEmailTextBox;
        private Guna.UI2.WinForms.Guna2TextBox sSurnameTextBox;
        private Guna.UI2.WinForms.Guna2TextBox sNameTextBox;
        private Guna.UI2.WinForms.Guna2DataGridView studentDataGridView;
        private Guna.UI2.WinForms.Guna2DateTimePicker sBDateTimePicker;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel birthDateLabel;
        private Guna.UI2.WinForms.Guna2Button deleteStudentButton;
        private Guna.UI2.WinForms.Guna2Button updateStudentButton;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2Button addStudentButton;
        private Guna.UI2.WinForms.Guna2Button addLibrarianButton;
    }
}