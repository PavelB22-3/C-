﻿namespace ND_LibraryManager.Forms
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(components);
            nameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            surnameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            birthDateTimePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            emailTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            RegistrationMainLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2RegisterButton = new Guna.UI2.WinForms.Guna2Button();
            password1TextBox = new Guna.UI2.WinForms.Guna2TextBox();
            password2TextBox = new Guna.UI2.WinForms.Guna2TextBox();
            registrationLabel6 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            registrationLabel5 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            registrationLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            registrationLabel2 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            registrationLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            registrationLabel4 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            addressTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            phoneNumTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            registrationLabel7 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            registrationLabel8 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 20;
            guna2Elipse1.TargetControl = this;
            // 
            // guna2DragControl1
            // 
            guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            guna2DragControl1.TargetControl = this;
            guna2DragControl1.UseTransparentDrag = true;
            // 
            // nameTextBox
            // 
            nameTextBox.AutoRoundedCorners = true;
            nameTextBox.BackColor = Color.Transparent;
            nameTextBox.BackgroundImageLayout = ImageLayout.None;
            nameTextBox.BorderColor = Color.Gray;
            nameTextBox.BorderRadius = 15;
            nameTextBox.BorderThickness = 2;
            nameTextBox.CustomizableEdges = customizableEdges18;
            nameTextBox.DefaultText = "";
            nameTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            nameTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            nameTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            nameTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            nameTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            nameTextBox.Font = new Font("Segoe UI", 9F);
            nameTextBox.ForeColor = Color.Black;
            nameTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            nameTextBox.Location = new Point(342, 57);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.PasswordChar = '\0';
            nameTextBox.PlaceholderText = "";
            nameTextBox.SelectedText = "";
            nameTextBox.ShadowDecoration.BorderRadius = 15;
            nameTextBox.ShadowDecoration.CustomizableEdges = customizableEdges19;
            nameTextBox.Size = new Size(194, 32);
            nameTextBox.TabIndex = 9;
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.Image = Properties.Resources.Login;
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(12, 80);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges17;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(324, 339);
            guna2CirclePictureBox1.TabIndex = 10;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // surnameTextBox
            // 
            surnameTextBox.AutoRoundedCorners = true;
            surnameTextBox.BackColor = Color.Transparent;
            surnameTextBox.BackgroundImageLayout = ImageLayout.None;
            surnameTextBox.BorderColor = Color.Gray;
            surnameTextBox.BorderRadius = 15;
            surnameTextBox.BorderThickness = 2;
            surnameTextBox.CustomizableEdges = customizableEdges15;
            surnameTextBox.DefaultText = "";
            surnameTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            surnameTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            surnameTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            surnameTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            surnameTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            surnameTextBox.Font = new Font("Segoe UI", 9F);
            surnameTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            surnameTextBox.Location = new Point(594, 57);
            surnameTextBox.Name = "surnameTextBox";
            surnameTextBox.PasswordChar = '\0';
            surnameTextBox.PlaceholderText = "";
            surnameTextBox.SelectedText = "";
            surnameTextBox.ShadowDecoration.BorderRadius = 15;
            surnameTextBox.ShadowDecoration.CustomizableEdges = customizableEdges16;
            surnameTextBox.Size = new Size(194, 32);
            surnameTextBox.TabIndex = 11;
            // 
            // birthDateTimePicker
            // 
            birthDateTimePicker.BorderColor = Color.Gray;
            birthDateTimePicker.BorderRadius = 15;
            birthDateTimePicker.BorderThickness = 2;
            birthDateTimePicker.Checked = true;
            birthDateTimePicker.CustomizableEdges = customizableEdges13;
            birthDateTimePicker.FillColor = Color.FromArgb(224, 224, 224);
            birthDateTimePicker.Font = new Font("Segoe UI", 9F);
            birthDateTimePicker.Format = DateTimePickerFormat.Long;
            birthDateTimePicker.Location = new Point(631, 120);
            birthDateTimePicker.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            birthDateTimePicker.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            birthDateTimePicker.Name = "birthDateTimePicker";
            birthDateTimePicker.ShadowDecoration.CustomizableEdges = customizableEdges14;
            birthDateTimePicker.Size = new Size(157, 36);
            birthDateTimePicker.TabIndex = 15;
            birthDateTimePicker.Value = new DateTime(2024, 10, 14, 13, 40, 39, 405);
            // 
            // emailTextBox
            // 
            emailTextBox.AutoRoundedCorners = true;
            emailTextBox.BackColor = Color.Transparent;
            emailTextBox.BackgroundImageLayout = ImageLayout.None;
            emailTextBox.BorderColor = Color.Gray;
            emailTextBox.BorderRadius = 15;
            emailTextBox.BorderThickness = 2;
            emailTextBox.CustomizableEdges = customizableEdges11;
            emailTextBox.DefaultText = "";
            emailTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            emailTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            emailTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            emailTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            emailTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            emailTextBox.Font = new Font("Segoe UI", 9F);
            emailTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            emailTextBox.Location = new Point(342, 124);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.PasswordChar = '\0';
            emailTextBox.PlaceholderText = "";
            emailTextBox.SelectedText = "";
            emailTextBox.ShadowDecoration.BorderRadius = 15;
            emailTextBox.ShadowDecoration.CustomizableEdges = customizableEdges12;
            emailTextBox.Size = new Size(237, 32);
            emailTextBox.TabIndex = 16;
            // 
            // RegistrationMainLabel1
            // 
            RegistrationMainLabel1.BackColor = Color.Transparent;
            RegistrationMainLabel1.Font = new Font("Segoe Print", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            RegistrationMainLabel1.Location = new Point(31, 12);
            RegistrationMainLabel1.Name = "RegistrationMainLabel1";
            RegistrationMainLabel1.Size = new Size(228, 67);
            RegistrationMainLabel1.TabIndex = 17;
            RegistrationMainLabel1.Text = "Registration";
            // 
            // guna2RegisterButton
            // 
            guna2RegisterButton.BorderRadius = 10;
            guna2RegisterButton.CustomizableEdges = customizableEdges9;
            guna2RegisterButton.DisabledState.BorderColor = Color.DarkGray;
            guna2RegisterButton.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2RegisterButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2RegisterButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2RegisterButton.FillColor = Color.Green;
            guna2RegisterButton.Font = new Font("Segoe UI", 9F);
            guna2RegisterButton.ForeColor = Color.White;
            guna2RegisterButton.Location = new Point(532, 393);
            guna2RegisterButton.Name = "guna2RegisterButton";
            guna2RegisterButton.PressedColor = Color.Lime;
            guna2RegisterButton.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2RegisterButton.Size = new Size(153, 45);
            guna2RegisterButton.TabIndex = 19;
            guna2RegisterButton.Text = "Register";
            guna2RegisterButton.Click += guna2RegisterButton_Click;
            // 
            // password1TextBox
            // 
            password1TextBox.AutoRoundedCorners = true;
            password1TextBox.BackColor = Color.Transparent;
            password1TextBox.BackgroundImageLayout = ImageLayout.None;
            password1TextBox.BorderColor = Color.Gray;
            password1TextBox.BorderRadius = 15;
            password1TextBox.BorderThickness = 2;
            password1TextBox.CustomizableEdges = customizableEdges7;
            password1TextBox.DefaultText = "";
            password1TextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            password1TextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            password1TextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            password1TextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            password1TextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            password1TextBox.Font = new Font("Segoe UI", 9F);
            password1TextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            password1TextBox.Location = new Point(481, 283);
            password1TextBox.Name = "password1TextBox";
            password1TextBox.PasswordChar = '\0';
            password1TextBox.PlaceholderText = "";
            password1TextBox.SelectedText = "";
            password1TextBox.ShadowDecoration.BorderRadius = 15;
            password1TextBox.ShadowDecoration.CustomizableEdges = customizableEdges8;
            password1TextBox.Size = new Size(258, 32);
            password1TextBox.TabIndex = 20;
            // 
            // password2TextBox
            // 
            password2TextBox.AutoRoundedCorners = true;
            password2TextBox.BackColor = Color.Transparent;
            password2TextBox.BackgroundImageLayout = ImageLayout.None;
            password2TextBox.BorderColor = Color.Gray;
            password2TextBox.BorderRadius = 15;
            password2TextBox.BorderThickness = 2;
            password2TextBox.CustomizableEdges = customizableEdges5;
            password2TextBox.DefaultText = "";
            password2TextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            password2TextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            password2TextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            password2TextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            password2TextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            password2TextBox.Font = new Font("Segoe UI", 9F);
            password2TextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            password2TextBox.Location = new Point(481, 341);
            password2TextBox.Name = "password2TextBox";
            password2TextBox.PasswordChar = '\0';
            password2TextBox.PlaceholderText = "";
            password2TextBox.SelectedText = "";
            password2TextBox.ShadowDecoration.BorderRadius = 15;
            password2TextBox.ShadowDecoration.CustomizableEdges = customizableEdges6;
            password2TextBox.Size = new Size(258, 32);
            password2TextBox.TabIndex = 21;
            // 
            // registrationLabel6
            // 
            registrationLabel6.BackColor = Color.Transparent;
            registrationLabel6.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registrationLabel6.ForeColor = SystemColors.ControlDark;
            registrationLabel6.Location = new Point(481, 321);
            registrationLabel6.Name = "registrationLabel6";
            registrationLabel6.Size = new Size(107, 19);
            registrationLabel6.TabIndex = 22;
            registrationLabel6.Text = "Repeat Password";
            // 
            // registrationLabel5
            // 
            registrationLabel5.BackColor = Color.Transparent;
            registrationLabel5.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registrationLabel5.ForeColor = SystemColors.ControlDark;
            registrationLabel5.Location = new Point(481, 260);
            registrationLabel5.Name = "registrationLabel5";
            registrationLabel5.Size = new Size(61, 19);
            registrationLabel5.TabIndex = 23;
            registrationLabel5.Text = "Password";
            // 
            // registrationLabel1
            // 
            registrationLabel1.BackColor = Color.Transparent;
            registrationLabel1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registrationLabel1.ForeColor = SystemColors.ControlDark;
            registrationLabel1.Location = new Point(342, 35);
            registrationLabel1.Name = "registrationLabel1";
            registrationLabel1.Size = new Size(39, 19);
            registrationLabel1.TabIndex = 24;
            registrationLabel1.Text = "Name";
            // 
            // registrationLabel2
            // 
            registrationLabel2.BackColor = Color.Transparent;
            registrationLabel2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registrationLabel2.ForeColor = SystemColors.ControlDark;
            registrationLabel2.Location = new Point(594, 36);
            registrationLabel2.Name = "registrationLabel2";
            registrationLabel2.Size = new Size(57, 19);
            registrationLabel2.TabIndex = 25;
            registrationLabel2.Text = "Surname";
            // 
            // registrationLabel3
            // 
            registrationLabel3.BackColor = Color.Transparent;
            registrationLabel3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registrationLabel3.ForeColor = SystemColors.ControlDark;
            registrationLabel3.Location = new Point(631, 101);
            registrationLabel3.Name = "registrationLabel3";
            registrationLabel3.Size = new Size(66, 19);
            registrationLabel3.TabIndex = 26;
            registrationLabel3.Text = "Birth Date";
            // 
            // registrationLabel4
            // 
            registrationLabel4.BackColor = Color.Transparent;
            registrationLabel4.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registrationLabel4.ForeColor = SystemColors.ControlDark;
            registrationLabel4.Location = new Point(342, 103);
            registrationLabel4.Name = "registrationLabel4";
            registrationLabel4.Size = new Size(37, 19);
            registrationLabel4.TabIndex = 27;
            registrationLabel4.Text = "Email";
            // 
            // addressTextBox
            // 
            addressTextBox.AutoRoundedCorners = true;
            addressTextBox.BackColor = Color.Transparent;
            addressTextBox.BackgroundImageLayout = ImageLayout.None;
            addressTextBox.BorderColor = Color.Gray;
            addressTextBox.BorderRadius = 15;
            addressTextBox.BorderThickness = 2;
            addressTextBox.CustomizableEdges = customizableEdges3;
            addressTextBox.DefaultText = "";
            addressTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            addressTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            addressTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            addressTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            addressTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            addressTextBox.Font = new Font("Segoe UI", 9F);
            addressTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            addressTextBox.Location = new Point(342, 193);
            addressTextBox.Name = "addressTextBox";
            addressTextBox.PasswordChar = '\0';
            addressTextBox.PlaceholderText = "";
            addressTextBox.SelectedText = "";
            addressTextBox.ShadowDecoration.BorderRadius = 15;
            addressTextBox.ShadowDecoration.CustomizableEdges = customizableEdges4;
            addressTextBox.Size = new Size(194, 32);
            addressTextBox.TabIndex = 28;
            addressTextBox.Visible = false;
            // 
            // phoneNumTextBox
            // 
            phoneNumTextBox.AutoRoundedCorners = true;
            phoneNumTextBox.BackColor = Color.Transparent;
            phoneNumTextBox.BackgroundImageLayout = ImageLayout.None;
            phoneNumTextBox.BorderColor = Color.Gray;
            phoneNumTextBox.BorderRadius = 15;
            phoneNumTextBox.BorderThickness = 2;
            phoneNumTextBox.CustomizableEdges = customizableEdges1;
            phoneNumTextBox.DefaultText = "";
            phoneNumTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            phoneNumTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            phoneNumTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            phoneNumTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            phoneNumTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            phoneNumTextBox.Font = new Font("Segoe UI", 9F);
            phoneNumTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            phoneNumTextBox.Location = new Point(594, 193);
            phoneNumTextBox.Name = "phoneNumTextBox";
            phoneNumTextBox.PasswordChar = '\0';
            phoneNumTextBox.PlaceholderText = "";
            phoneNumTextBox.SelectedText = "";
            phoneNumTextBox.ShadowDecoration.BorderRadius = 15;
            phoneNumTextBox.ShadowDecoration.CustomizableEdges = customizableEdges2;
            phoneNumTextBox.Size = new Size(194, 32);
            phoneNumTextBox.TabIndex = 29;
            phoneNumTextBox.Visible = false;
            // 
            // registrationLabel7
            // 
            registrationLabel7.BackColor = Color.Transparent;
            registrationLabel7.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registrationLabel7.ForeColor = SystemColors.ControlDark;
            registrationLabel7.Location = new Point(342, 172);
            registrationLabel7.Name = "registrationLabel7";
            registrationLabel7.Size = new Size(52, 19);
            registrationLabel7.TabIndex = 30;
            registrationLabel7.Text = "Address";
            registrationLabel7.Visible = false;
            // 
            // registrationLabel8
            // 
            registrationLabel8.BackColor = Color.Transparent;
            registrationLabel8.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            registrationLabel8.ForeColor = SystemColors.ControlDark;
            registrationLabel8.Location = new Point(594, 172);
            registrationLabel8.Name = "registrationLabel8";
            registrationLabel8.Size = new Size(96, 19);
            registrationLabel8.TabIndex = 31;
            registrationLabel8.Text = "Phone Number";
            registrationLabel8.Visible = false;
            // 
            // RegistrationForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(47, 83, 70);
            ClientSize = new Size(800, 450);
            Controls.Add(registrationLabel8);
            Controls.Add(registrationLabel7);
            Controls.Add(phoneNumTextBox);
            Controls.Add(addressTextBox);
            Controls.Add(registrationLabel4);
            Controls.Add(registrationLabel3);
            Controls.Add(registrationLabel2);
            Controls.Add(registrationLabel1);
            Controls.Add(registrationLabel5);
            Controls.Add(registrationLabel6);
            Controls.Add(password2TextBox);
            Controls.Add(password1TextBox);
            Controls.Add(guna2RegisterButton);
            Controls.Add(RegistrationMainLabel1);
            Controls.Add(emailTextBox);
            Controls.Add(birthDateTimePicker);
            Controls.Add(surnameTextBox);
            Controls.Add(guna2CirclePictureBox1);
            Controls.Add(nameTextBox);
            FormBorderStyle = FormBorderStyle.None;
            Name = "RegistrationForm";
            Text = "RegistrationForm";
            Load += RegistrationForm_Load;
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2TextBox nameTextBox;
        private Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2TextBox surnameTextBox;
        private Guna.UI2.WinForms.Guna2DateTimePicker birthDateTimePicker;
        private Guna.UI2.WinForms.Guna2TextBox emailTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel RegistrationMainLabel1;
        private Guna.UI2.WinForms.Guna2Button guna2RegisterButton;
        private Guna.UI2.WinForms.Guna2TextBox password2TextBox;
        private Guna.UI2.WinForms.Guna2TextBox password1TextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel registrationLabel6;
        private Guna.UI2.WinForms.Guna2HtmlLabel registrationLabel5;
        private Guna.UI2.WinForms.Guna2HtmlLabel registrationLabel4;
        private Guna.UI2.WinForms.Guna2HtmlLabel registrationLabel3;
        private Guna.UI2.WinForms.Guna2HtmlLabel registrationLabel2;
        private Guna.UI2.WinForms.Guna2HtmlLabel registrationLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel registrationLabel8;
        private Guna.UI2.WinForms.Guna2HtmlLabel registrationLabel7;
        private Guna.UI2.WinForms.Guna2TextBox phoneNumTextBox;
        private Guna.UI2.WinForms.Guna2TextBox addressTextBox;
    }
}