using Microsoft.VisualBasic.ApplicationServices;
using ND_LibraryManager.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace ND_LibraryManager
{
    public partial class LoginForm : Form
    {
        private Library library;
        public LoginForm(Library library)
        {
            InitializeComponent();
            this.library = library;
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string userId = loginTextBox.Text;
            string password = passwordTextBox.Text;
            if (!int.TryParse(userId, out int id))//out
            {
                MessageBox.Show("Invalid ID format.");
                return;
            }
            LibraryUser user = library.Login(id, password);

            switch (user)//switch su when
            {
                case Librarian librarian when librarian != null:
                    LibrarianForm librarianForm = new LibrarianForm(library, librarian);
                    this.Hide();
                    librarianForm.ShowDialog();
                    break;
                case Student student when student != null:
                    StudentForm studentForm = new StudentForm(library, student);
                    this.Hide();
                    studentForm.ShowDialog();
                    break;
                default:
                    MessageBox.Show("Wrong login or password");
                    break;
            }
            this.Show();
        }

        private void signUpLink_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm(library, false);
            this.Hide();
            registrationForm.ShowDialog();
            this.Show();
        }
    }
}
