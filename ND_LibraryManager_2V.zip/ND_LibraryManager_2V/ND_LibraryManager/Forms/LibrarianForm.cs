﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ND_LibraryManager.Forms
{
    public partial class LibrarianForm : Form
    {
        Library library;
        private Librarian currentLibrarian;
        public LibrarianForm(Library library, Librarian librarian)
        {
            InitializeComponent();
            this.library = library;
            this.currentLibrarian = librarian;

            LoadAccountInfo();
        }
        private void TabIndexChanged(object sender, EventArgs e)
        {
            LoadAccountInfo();
            LoadBooks();
            LoadStudents();
        }
        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Account
        private void LoadAccountInfo()
        {
            idLabel.Text = currentLibrarian.ID.ToString();
            //txtPassword.Text = currentLibrarian.Password; 
            nameTextBox.Text = currentLibrarian.Name;
            surnameTextBox.Text = currentLibrarian.Surname;
            emailTextBox.Text = currentLibrarian.Email;
            birthDateTimePicker.Value = currentLibrarian.BirthDate;
            phoneNumTextBox.Text = currentLibrarian.PhoneNum;
            addressTextBox.Text = currentLibrarian.Address;

            saveButton.Enabled = false;
        }
        private void saveButton_Click(object sender, EventArgs e)
        {
            currentLibrarian.Email = emailTextBox.Text;
            currentLibrarian.Name = nameTextBox.Text;
            currentLibrarian.Surname = surnameTextBox.Text;
            currentLibrarian.BirthDate = birthDateTimePicker.Value;
            currentLibrarian.PhoneNum = phoneNumTextBox.Text;
            currentLibrarian.Address = addressTextBox.Text;

            library.UpdateUser(currentLibrarian);
            MessageBox.Show("Information succesfully updated!");

            saveButton.Enabled = false;
        }
        private void UserInfoChanged(object sender, EventArgs e)
        {
            saveButton.Enabled = true;
        }
        private void deleteAccButton_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to permanently remove this account?", "Confirm Deletion", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                library.RemoveEntity<Librarian>(currentLibrarian.ID);
                MessageBox.Show("Account deleted succesfully.");
                this.Close();
            }
            else
            {
                MessageBox.Show("Error ocured", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //Books
        private void LoadBooks()
        {
            booksDataGridView.DataSource = null;

            booksDataGridView.DataSource ??= library.GetBooks();
            booksDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            booksDataGridView.ColumnHeadersHeight = 30;
            booksDataGridView.RowTemplate.Height = 30;
            booksDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            booksDataGridView.MultiSelect = false;
            booksDataGridView.ReadOnly = true;

            booksDataGridView.Columns["Title"].HeaderText = "Title";
            booksDataGridView.Columns["Author"].HeaderText = "Author";
            booksDataGridView.Columns["ISBN"].HeaderText = "ISBN";
            booksDataGridView.Columns["PublishDate"].HeaderText = "Publish Date";
            booksDataGridView.Columns["Quantity"].HeaderText = "Quantity";
            booksDataGridView.Columns["BorrowedBooks"].Visible = false;

            booksDataGridView.ClearSelection();
            clearBookTextFields();

        }

        private void clearBookTextFields()
        {
            titleTextBox.Text = "";
            authorTextBox.Text = "";
            ISBNTextBox.Text = "";
            publishedDateTimePicker.Value = DateTime.Now;
            quantityNumericUpDown.Value = 1;
        }

        private void bookSelected(object sender, EventArgs e)
        {

            if (booksDataGridView.SelectedRows.Count > 0)
            {
                var selectedBook = (Book)booksDataGridView.SelectedRows[0].DataBoundItem;

                titleTextBox.Text = selectedBook.Title;
                authorTextBox.Text = selectedBook.Author;
                ISBNTextBox.Text = selectedBook.ISBN;
                publishedDateTimePicker.Value = selectedBook.PublishDate;
                quantityNumericUpDown.Value = selectedBook.Quantity;

                deleteBookButton.Enabled = true;
            }
        }

        private void deleteBookButton_Click(object sender, EventArgs e)
        {
            if (booksDataGridView.SelectedRows.Count > 0)
            {
                var selectedBook = (Book)booksDataGridView.SelectedRows[0].DataBoundItem;
                library.RemoveEntity<Book>(selectedBook.ID);
                LoadBooks();
                MessageBox.Show("Book deleted successfully!");
            }
            else
            {
                MessageBox.Show("Please select a book to delete.");
            }
        }

        private void updateBookButton_Click(object sender, EventArgs e)
        {
            if (booksDataGridView.SelectedRows.Count > 0)
            {
                var selectedBook = (Book)booksDataGridView.SelectedRows[0].DataBoundItem;

                selectedBook.Title = titleTextBox.Text;
                selectedBook.Author = authorTextBox.Text;
                selectedBook.ISBN = ISBNTextBox.Text;
                selectedBook.PublishDate = publishedDateTimePicker.Value;
                selectedBook.Quantity = (int)quantityNumericUpDown.Value;

                library.UpdateBook(selectedBook);
                LoadBooks();
                MessageBox.Show("Book updated successfully!");
            }
            else
            {
                MessageBox.Show("Please select a book to update.");
            }
        }
        private void addBookButton_Click(object sender, EventArgs e)
        {
            Book book = new Book(titleTextBox.Text, authorTextBox.Text, ISBNTextBox.Text, publishedDateTimePicker.Value, (int)quantityNumericUpDown.Value);
            library.AddBook(book);
            LoadBooks();
        }

        //Students
        private void LoadStudents()
        {
            studentDataGridView.DataSource = null;

            studentDataGridView.DataSource ??= library.GetStudents();
            studentDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            studentDataGridView.ColumnHeadersHeight = 30;
            studentDataGridView.RowTemplate.Height = 30;
            studentDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            studentDataGridView.MultiSelect = false;
            studentDataGridView.ReadOnly = true;

            studentDataGridView.Columns["Name"].HeaderText = "Name";
            studentDataGridView.Columns["Surname"].HeaderText = "Surname";
            studentDataGridView.Columns["Email"].HeaderText = "Email";
            studentDataGridView.Columns["BirthDate"].HeaderText = "Birth Date";
            studentDataGridView.Columns["BorrowedBooks"].Visible = false;
            studentDataGridView.Columns["UserType"].Visible = false;
            studentDataGridView.ClearSelection();
            clearStudentTextFields();
            studentDataGridView.Refresh();
        }

        private void clearStudentTextFields()
        {
            sNameTextBox.Text = string.Empty;
            sSurnameTextBox.Text = string.Empty;
            sEmailTextBox.Text = string.Empty;
            sBDateTimePicker.Value = DateTime.Now;
        }

        private void studentSelected(object sender, EventArgs e)
        {
            if (studentDataGridView.SelectedRows.Count > 0)
            {
                var selectedStudent = (Student)studentDataGridView.SelectedRows[0].DataBoundItem;

                sNameTextBox.Text = selectedStudent.Name;
                sSurnameTextBox.Text = selectedStudent.Surname;
                sEmailTextBox.Text = selectedStudent.Email;
                sBDateTimePicker.Value = selectedStudent.BirthDate;
            }

        }

        private void deleteStudentButton_Click(object sender, EventArgs e)
        {
            if (studentDataGridView.SelectedRows.Count > 0)
            {
                var selectedStudent = (Student)studentDataGridView.SelectedRows[0].DataBoundItem;
                library.RemoveEntity<Student>(selectedStudent.ID);

                LoadStudents();
                MessageBox.Show("Student deleted successfully!");
            }
            else
            {
                MessageBox.Show("Please select a Student to delete.");
            }
            studentDataGridView.ClearSelection();
        }

        private void updateStudentButton_Click(object sender, EventArgs e)
        {
            Student selectedStudent = (Student)studentDataGridView.SelectedRows[0].DataBoundItem;
            selectedStudent.Email = sEmailTextBox.Text;
            selectedStudent.Name = sNameTextBox.Text;
            selectedStudent.Surname = sSurnameTextBox.Text;
            selectedStudent.BirthDate = sBDateTimePicker.Value;

            library.UpdateUser(selectedStudent);
            LoadStudents();

            MessageBox.Show("Information succesfully updated!");
        }

        private void LibrarianForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            //library.SaveDataToFiles();
        }

        private void addStudentButton_Click(object sender, EventArgs e)
        {

            if (!Regex.IsMatch(sNameTextBox.Text, "^[A-Z][a-z]*$"))
            {
                MessageBox.Show("Invalid Name format.");
                return;
            }
            else if (!Regex.IsMatch(sSurnameTextBox.Text, "^[A-Z][a-z]*$"))
            {
                MessageBox.Show("Invalid Surname format.");
                return;
            }
            else if (!Regex.IsMatch(sEmailTextBox.Text, "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"))
            {
                MessageBox.Show("Invalid Email format.");
                return;
            }
            int id = library.GenerateUniqueId(false);
            Student student = new Student(sNameTextBox.Text, sSurnameTextBox.Text, sEmailTextBox.Text, id, "password123", sBDateTimePicker.Value);
            library.AddUser(student);

            LoadStudents();
        }

        private void addLibrarianButton_Click(object sender, EventArgs e)
        {
            RegistrationForm registrationForm = new RegistrationForm(library, true);
            this.Hide();
            registrationForm.ShowDialog();
            this.Show();
        }
    }
}
