﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ND_LibraryManager.Forms
{
    public partial class RegistrationForm : Form
    {
        private Library library;
        private bool isLibrarian;
        public RegistrationForm(Library library, bool isLibrarian)
        {
            InitializeComponent();
            this.library = library;
            this.isLibrarian = isLibrarian;
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {
            if (isLibrarian)
            {
                registrationLabel7.Visible = true;
                registrationLabel8.Visible = true;
                addressTextBox.Visible = true;
                phoneNumTextBox.Visible = true;
            }
        }

        private void guna2RegisterButton_Click(object sender, EventArgs e)
        {
            if (!Regex.IsMatch(nameTextBox.Text,"^[A-Z][a-z]*$"))
            {
                MessageBox.Show("Invalid Name format.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }else if(!Regex.IsMatch(surnameTextBox.Text, "^[A-Z][a-z]*$"))
            {
                MessageBox.Show("Invalid Surname format.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }else if(!Regex.IsMatch(emailTextBox.Text, "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$") )
            {
                MessageBox.Show("Invalid email format.","Warning",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                return;
            }
            else if(password1TextBox.Text != password2TextBox.Text || password2TextBox.Text == string.Empty)
            {
                MessageBox.Show("Passwords dont't match.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;           
            }
            else if(isLibrarian && (addressTextBox.Text == string.Empty || phoneNumTextBox.Text == string.Empty))
            {
                MessageBox.Show("All field must be filled in.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            
            int id = library.GenerateUniqueId(isLibrarian);
            MessageBox.Show("Your User Id is: " + id+ "\nRemember IT!!!!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            if(isLibrarian)
            {
                Librarian librarian = new Librarian(nameTextBox.Text, surnameTextBox.Text, emailTextBox.Text, id, password2TextBox.Text, 
                birthDateTimePicker.Value, phoneNumTextBox.Text, addressTextBox.Text);
                library.AddUser(librarian);
            }
            else
            {
                Student student = new Student(nameTextBox.Text, surnameTextBox.Text,emailTextBox.Text,id, password2TextBox.Text, birthDateTimePicker.Value);                             
                library.AddUser(student);
            }
                              
            this.Close();
        }
    }
}
