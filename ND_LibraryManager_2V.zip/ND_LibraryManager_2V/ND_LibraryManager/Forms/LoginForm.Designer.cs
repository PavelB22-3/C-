﻿namespace ND_LibraryManager
{
    partial class LoginForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            guna2DragControl1 = new Guna.UI2.WinForms.Guna2DragControl(components);
            guna2Panel1 = new Guna.UI2.WinForms.Guna2Panel();
            guna2PictureBox1 = new Guna.UI2.WinForms.Guna2PictureBox();
            loginMainLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            signUpLink = new LinkLabel();
            signUpLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            loginButton = new Guna.UI2.WinForms.Guna2Button();
            loginTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            passwordTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            loginLabel3 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            passwordLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            guna2Panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 20;
            guna2Elipse1.TargetControl = this;
            // 
            // guna2DragControl1
            // 
            guna2DragControl1.DockIndicatorTransparencyValue = 0.6D;
            guna2DragControl1.TargetControl = this;
            guna2DragControl1.UseTransparentDrag = true;
            // 
            // guna2Panel1
            // 
            guna2Panel1.Controls.Add(guna2PictureBox1);
            guna2Panel1.CustomizableEdges = customizableEdges29;
            guna2Panel1.Dock = DockStyle.Right;
            guna2Panel1.Location = new Point(364, 0);
            guna2Panel1.Name = "guna2Panel1";
            guna2Panel1.ShadowDecoration.CustomizableEdges = customizableEdges30;
            guna2Panel1.Size = new Size(436, 450);
            guna2Panel1.TabIndex = 2;
            // 
            // guna2PictureBox1
            // 
            guna2PictureBox1.CustomizableEdges = customizableEdges27;
            guna2PictureBox1.Dock = DockStyle.Fill;
            guna2PictureBox1.Image = Properties.Resources.Login;
            guna2PictureBox1.ImageRotate = 0F;
            guna2PictureBox1.Location = new Point(0, 0);
            guna2PictureBox1.Name = "guna2PictureBox1";
            guna2PictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges28;
            guna2PictureBox1.Size = new Size(436, 450);
            guna2PictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            guna2PictureBox1.TabIndex = 0;
            guna2PictureBox1.TabStop = false;
            // 
            // loginMainLabel1
            // 
            loginMainLabel1.BackColor = Color.Transparent;
            loginMainLabel1.Font = new Font("Segoe Print", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loginMainLabel1.Location = new Point(130, 12);
            loginMainLabel1.Name = "loginMainLabel1";
            loginMainLabel1.Size = new Size(103, 67);
            loginMainLabel1.TabIndex = 3;
            loginMainLabel1.Text = "Login";
            // 
            // signUpLink
            // 
            signUpLink.AutoSize = true;
            signUpLink.Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            signUpLink.LinkColor = Color.MediumBlue;
            signUpLink.Location = new Point(184, 334);
            signUpLink.Name = "signUpLink";
            signUpLink.Size = new Size(61, 20);
            signUpLink.TabIndex = 4;
            signUpLink.TabStop = true;
            signUpLink.Text = "Sign Up";
            signUpLink.LinkClicked += signUpLink_LinkClicked;
            // 
            // signUpLabel
            // 
            signUpLabel.BackColor = Color.Transparent;
            signUpLabel.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            signUpLabel.ForeColor = SystemColors.ControlDark;
            signUpLabel.Location = new Point(12, 332);
            signUpLabel.Name = "signUpLabel";
            signUpLabel.Size = new Size(166, 22);
            signUpLabel.TabIndex = 5;
            signUpLabel.Text = "Don't have an account?";
            // 
            // loginButton
            // 
            loginButton.BorderRadius = 10;
            loginButton.CustomizableEdges = customizableEdges25;
            loginButton.DisabledState.BorderColor = Color.DarkGray;
            loginButton.DisabledState.CustomBorderColor = Color.DarkGray;
            loginButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            loginButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            loginButton.FillColor = Color.DarkGreen;
            loginButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loginButton.ForeColor = Color.White;
            loginButton.Location = new Point(86, 241);
            loginButton.Name = "loginButton";
            loginButton.PressedColor = Color.Lime;
            loginButton.ShadowDecoration.CustomizableEdges = customizableEdges26;
            loginButton.Size = new Size(180, 45);
            loginButton.TabIndex = 6;
            loginButton.Text = "LOGIN";
            loginButton.Click += loginButton_Click;
            // 
            // loginTextBox
            // 
            loginTextBox.BorderRadius = 10;
            loginTextBox.CustomizableEdges = customizableEdges23;
            loginTextBox.DefaultText = "";
            loginTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            loginTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            loginTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            loginTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            loginTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            loginTextBox.Font = new Font("Segoe UI", 9F);
            loginTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            loginTextBox.Location = new Point(38, 102);
            loginTextBox.Name = "loginTextBox";
            loginTextBox.PasswordChar = '\0';
            loginTextBox.PlaceholderText = "";
            loginTextBox.SelectedText = "";
            loginTextBox.ShadowDecoration.CustomizableEdges = customizableEdges24;
            loginTextBox.Size = new Size(266, 37);
            loginTextBox.TabIndex = 7;
            // 
            // passwordTextBox
            // 
            passwordTextBox.BorderRadius = 10;
            passwordTextBox.CustomizableEdges = customizableEdges21;
            passwordTextBox.DefaultText = "";
            passwordTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            passwordTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            passwordTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            passwordTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            passwordTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            passwordTextBox.Font = new Font("Segoe UI", 9F);
            passwordTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            passwordTextBox.Location = new Point(38, 170);
            passwordTextBox.Name = "passwordTextBox";
            passwordTextBox.PasswordChar = '\0';
            passwordTextBox.PlaceholderText = "";
            passwordTextBox.SelectedText = "";
            passwordTextBox.ShadowDecoration.CustomizableEdges = customizableEdges22;
            passwordTextBox.Size = new Size(266, 36);
            passwordTextBox.TabIndex = 8;
            // 
            // loginLabel3
            // 
            loginLabel3.BackColor = Color.Transparent;
            loginLabel3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            loginLabel3.ForeColor = SystemColors.ControlDark;
            loginLabel3.Location = new Point(38, 77);
            loginLabel3.Name = "loginLabel3";
            loginLabel3.Size = new Size(48, 19);
            loginLabel3.TabIndex = 9;
            loginLabel3.Text = "User ID";
            // 
            // passwordLabel
            // 
            passwordLabel.BackColor = Color.Transparent;
            passwordLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            passwordLabel.ForeColor = SystemColors.ControlDark;
            passwordLabel.Location = new Point(38, 145);
            passwordLabel.Name = "passwordLabel";
            passwordLabel.Size = new Size(61, 19);
            passwordLabel.TabIndex = 10;
            passwordLabel.Text = "Password";
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(57, 83, 80);
            ClientSize = new Size(800, 450);
            Controls.Add(passwordLabel);
            Controls.Add(loginLabel3);
            Controls.Add(passwordTextBox);
            Controls.Add(loginTextBox);
            Controls.Add(loginButton);
            Controls.Add(signUpLabel);
            Controls.Add(signUpLink);
            Controls.Add(loginMainLabel1);
            Controls.Add(guna2Panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "LoginForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            guna2Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)guna2PictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private Guna.UI2.WinForms.Guna2DragControl guna2DragControl1;
        private Guna.UI2.WinForms.Guna2Panel guna2Panel1;
        private Guna.UI2.WinForms.Guna2PictureBox guna2PictureBox1;
        private Guna.UI2.WinForms.Guna2HtmlLabel loginMainLabel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel signUpLabel;
        private LinkLabel signUpLink;
        private Guna.UI2.WinForms.Guna2Button loginButton;
        private Guna.UI2.WinForms.Guna2TextBox passwordTextBox;
        private Guna.UI2.WinForms.Guna2TextBox loginTextBox;
        private Guna.UI2.WinForms.Guna2HtmlLabel passwordLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel loginLabel3;
    }
}
