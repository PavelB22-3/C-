﻿namespace ND_LibraryManager.Forms
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            SturdentTabControl = new Guna.UI2.WinForms.Guna2TabControl();
            accountTab = new TabPage();
            birthDateLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            idLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            saveButton = new Guna.UI2.WinForms.Guna2Button();
            birthDateTimePicker = new Guna.UI2.WinForms.Guna2DateTimePicker();
            emailLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            surnameLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            nameLabel = new Guna.UI2.WinForms.Guna2HtmlLabel();
            emailTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            surnameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            nameTextBox = new Guna.UI2.WinForms.Guna2TextBox();
            deleteAccButton = new Guna.UI2.WinForms.Guna2Button();
            guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            guna2CirclePictureBox1 = new Guna.UI2.WinForms.Guna2CirclePictureBox();
            borrowTab = new TabPage();
            borrowButton = new Guna.UI2.WinForms.Guna2Button();
            borrowDataGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            returnTab = new TabPage();
            returnButton = new Guna.UI2.WinForms.Guna2Button();
            returnDataGridView = new Guna.UI2.WinForms.Guna2DataGridView();
            guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(components);
            closeButton = new Guna.UI2.WinForms.Guna2Button();
            SturdentTabControl.SuspendLayout();
            accountTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).BeginInit();
            borrowTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)borrowDataGridView).BeginInit();
            returnTab.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)returnDataGridView).BeginInit();
            SuspendLayout();
            // 
            // SturdentTabControl
            // 
            SturdentTabControl.Alignment = TabAlignment.Left;
            SturdentTabControl.AllowDrop = true;
            SturdentTabControl.Controls.Add(accountTab);
            SturdentTabControl.Controls.Add(borrowTab);
            SturdentTabControl.Controls.Add(returnTab);
            SturdentTabControl.Dock = DockStyle.Fill;
            SturdentTabControl.ItemSize = new Size(180, 40);
            SturdentTabControl.Location = new Point(0, 0);
            SturdentTabControl.Name = "SturdentTabControl";
            SturdentTabControl.SelectedIndex = 0;
            SturdentTabControl.Size = new Size(900, 500);
            SturdentTabControl.TabButtonHoverState.BorderColor = Color.Empty;
            SturdentTabControl.TabButtonHoverState.FillColor = Color.FromArgb(40, 52, 70);
            SturdentTabControl.TabButtonHoverState.Font = new Font("Segoe UI Semibold", 10F);
            SturdentTabControl.TabButtonHoverState.ForeColor = Color.White;
            SturdentTabControl.TabButtonHoverState.InnerColor = Color.FromArgb(40, 52, 70);
            SturdentTabControl.TabButtonIdleState.BorderColor = Color.Empty;
            SturdentTabControl.TabButtonIdleState.FillColor = Color.FromArgb(33, 42, 57);
            SturdentTabControl.TabButtonIdleState.Font = new Font("Segoe UI Semibold", 10F);
            SturdentTabControl.TabButtonIdleState.ForeColor = Color.FromArgb(156, 160, 167);
            SturdentTabControl.TabButtonIdleState.InnerColor = Color.FromArgb(33, 42, 57);
            SturdentTabControl.TabButtonSelectedState.BorderColor = Color.Empty;
            SturdentTabControl.TabButtonSelectedState.FillColor = Color.FromArgb(29, 27, 57);
            SturdentTabControl.TabButtonSelectedState.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SturdentTabControl.TabButtonSelectedState.ForeColor = Color.White;
            SturdentTabControl.TabButtonSelectedState.InnerColor = Color.FromArgb(76, 132, 255);
            SturdentTabControl.TabButtonSize = new Size(180, 40);
            SturdentTabControl.TabIndex = 0;
            SturdentTabControl.TabMenuBackColor = Color.FromArgb(33, 42, 57);
            SturdentTabControl.SelectedIndexChanged += tabIndexChenged;
            // 
            // accountTab
            // 
            accountTab.AllowDrop = true;
            accountTab.Controls.Add(birthDateLabel);
            accountTab.Controls.Add(idLabel);
            accountTab.Controls.Add(saveButton);
            accountTab.Controls.Add(birthDateTimePicker);
            accountTab.Controls.Add(emailLabel);
            accountTab.Controls.Add(surnameLabel);
            accountTab.Controls.Add(nameLabel);
            accountTab.Controls.Add(emailTextBox);
            accountTab.Controls.Add(surnameTextBox);
            accountTab.Controls.Add(nameTextBox);
            accountTab.Controls.Add(deleteAccButton);
            accountTab.Controls.Add(guna2Button1);
            accountTab.Controls.Add(guna2CirclePictureBox1);
            accountTab.Location = new Point(184, 4);
            accountTab.Name = "accountTab";
            accountTab.Padding = new Padding(3);
            accountTab.Size = new Size(712, 492);
            accountTab.TabIndex = 0;
            accountTab.Text = "Account";
            accountTab.UseVisualStyleBackColor = true;
            // 
            // birthDateLabel
            // 
            birthDateLabel.BackColor = Color.Transparent;
            birthDateLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            birthDateLabel.ForeColor = SystemColors.ControlDark;
            birthDateLabel.Location = new Point(351, 173);
            birthDateLabel.Name = "birthDateLabel";
            birthDateLabel.Size = new Size(66, 19);
            birthDateLabel.TabIndex = 26;
            birthDateLabel.Text = "Birth Date";
            // 
            // idLabel
            // 
            idLabel.BackColor = Color.Transparent;
            idLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            idLabel.ForeColor = SystemColors.ControlDark;
            idLabel.Location = new Point(95, 156);
            idLabel.Name = "idLabel";
            idLabel.Size = new Size(17, 19);
            idLabel.TabIndex = 25;
            idLabel.Text = "ID";
            // 
            // saveButton
            // 
            saveButton.BorderRadius = 25;
            saveButton.CustomizableEdges = customizableEdges1;
            saveButton.DisabledState.BorderColor = Color.DarkGray;
            saveButton.DisabledState.CustomBorderColor = Color.DarkGray;
            saveButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            saveButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            saveButton.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            saveButton.ForeColor = Color.White;
            saveButton.Location = new Point(402, 382);
            saveButton.Name = "saveButton";
            saveButton.ShadowDecoration.CustomizableEdges = customizableEdges2;
            saveButton.Size = new Size(146, 46);
            saveButton.TabIndex = 15;
            saveButton.Text = "Save Changes";
            saveButton.Click += saveButton_Click;
            // 
            // birthDateTimePicker
            // 
            birthDateTimePicker.BorderColor = Color.Gray;
            birthDateTimePicker.BorderRadius = 15;
            birthDateTimePicker.BorderThickness = 2;
            birthDateTimePicker.Checked = true;
            birthDateTimePicker.CustomizableEdges = customizableEdges3;
            birthDateTimePicker.FillColor = Color.FromArgb(224, 224, 224);
            birthDateTimePicker.Font = new Font("Segoe UI", 9F);
            birthDateTimePicker.Format = DateTimePickerFormat.Long;
            birthDateTimePicker.Location = new Point(342, 198);
            birthDateTimePicker.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            birthDateTimePicker.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            birthDateTimePicker.Name = "birthDateTimePicker";
            birthDateTimePicker.ShadowDecoration.CustomizableEdges = customizableEdges4;
            birthDateTimePicker.Size = new Size(258, 36);
            birthDateTimePicker.TabIndex = 14;
            birthDateTimePicker.Value = new DateTime(2024, 10, 14, 13, 40, 39, 405);
            birthDateTimePicker.ValueChanged += userInfoChanged;
            // 
            // emailLabel
            // 
            emailLabel.BackColor = Color.Transparent;
            emailLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            emailLabel.ForeColor = SystemColors.ControlDark;
            emailLabel.Location = new Point(351, 274);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new Size(37, 19);
            emailLabel.TabIndex = 13;
            emailLabel.Text = "Email";
            // 
            // surnameLabel
            // 
            surnameLabel.BackColor = Color.Transparent;
            surnameLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            surnameLabel.ForeColor = SystemColors.ControlDark;
            surnameLabel.Location = new Point(351, 101);
            surnameLabel.Name = "surnameLabel";
            surnameLabel.Size = new Size(57, 19);
            surnameLabel.TabIndex = 12;
            surnameLabel.Text = "Surname";
            // 
            // nameLabel
            // 
            nameLabel.BackColor = Color.Transparent;
            nameLabel.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            nameLabel.ForeColor = SystemColors.ControlDark;
            nameLabel.Location = new Point(351, 38);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(39, 19);
            nameLabel.TabIndex = 11;
            nameLabel.Text = "Name";
            // 
            // emailTextBox
            // 
            emailTextBox.AutoRoundedCorners = true;
            emailTextBox.BackColor = Color.Transparent;
            emailTextBox.BackgroundImageLayout = ImageLayout.None;
            emailTextBox.BorderColor = Color.Gray;
            emailTextBox.BorderRadius = 15;
            emailTextBox.BorderThickness = 2;
            emailTextBox.CustomizableEdges = customizableEdges5;
            emailTextBox.DefaultText = "";
            emailTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            emailTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            emailTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            emailTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            emailTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            emailTextBox.Font = new Font("Segoe UI", 9F);
            emailTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            emailTextBox.Location = new Point(342, 299);
            emailTextBox.Name = "emailTextBox";
            emailTextBox.PasswordChar = '\0';
            emailTextBox.PlaceholderText = "";
            emailTextBox.SelectedText = "";
            emailTextBox.ShadowDecoration.BorderRadius = 15;
            emailTextBox.ShadowDecoration.CustomizableEdges = customizableEdges6;
            emailTextBox.Size = new Size(258, 32);
            emailTextBox.TabIndex = 10;
            emailTextBox.TextChanged += userInfoChanged;
            // 
            // surnameTextBox
            // 
            surnameTextBox.AutoRoundedCorners = true;
            surnameTextBox.BackColor = Color.Transparent;
            surnameTextBox.BackgroundImageLayout = ImageLayout.None;
            surnameTextBox.BorderColor = Color.Gray;
            surnameTextBox.BorderRadius = 15;
            surnameTextBox.BorderThickness = 2;
            surnameTextBox.CustomizableEdges = customizableEdges7;
            surnameTextBox.DefaultText = "";
            surnameTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            surnameTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            surnameTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            surnameTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            surnameTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            surnameTextBox.Font = new Font("Segoe UI", 9F);
            surnameTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            surnameTextBox.Location = new Point(342, 126);
            surnameTextBox.Name = "surnameTextBox";
            surnameTextBox.PasswordChar = '\0';
            surnameTextBox.PlaceholderText = "";
            surnameTextBox.SelectedText = "";
            surnameTextBox.ShadowDecoration.BorderRadius = 15;
            surnameTextBox.ShadowDecoration.CustomizableEdges = customizableEdges8;
            surnameTextBox.Size = new Size(258, 32);
            surnameTextBox.TabIndex = 9;
            surnameTextBox.TextChanged += userInfoChanged;
            // 
            // nameTextBox
            // 
            nameTextBox.AutoRoundedCorners = true;
            nameTextBox.BackColor = Color.Transparent;
            nameTextBox.BackgroundImageLayout = ImageLayout.None;
            nameTextBox.BorderColor = Color.Gray;
            nameTextBox.BorderRadius = 15;
            nameTextBox.BorderThickness = 2;
            nameTextBox.CustomizableEdges = customizableEdges9;
            nameTextBox.DefaultText = "";
            nameTextBox.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            nameTextBox.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            nameTextBox.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            nameTextBox.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            nameTextBox.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            nameTextBox.Font = new Font("Segoe UI", 9F);
            nameTextBox.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            nameTextBox.Location = new Point(342, 63);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.PasswordChar = '\0';
            nameTextBox.PlaceholderText = "";
            nameTextBox.SelectedText = "";
            nameTextBox.ShadowDecoration.BorderRadius = 15;
            nameTextBox.ShadowDecoration.CustomizableEdges = customizableEdges10;
            nameTextBox.Size = new Size(258, 32);
            nameTextBox.TabIndex = 8;
            nameTextBox.TextChanged += userInfoChanged;
            // 
            // deleteAccButton
            // 
            deleteAccButton.BorderRadius = 15;
            deleteAccButton.CustomizableEdges = customizableEdges11;
            deleteAccButton.DisabledState.BorderColor = Color.DarkGray;
            deleteAccButton.DisabledState.CustomBorderColor = Color.DarkGray;
            deleteAccButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            deleteAccButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            deleteAccButton.FillColor = Color.Red;
            deleteAccButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            deleteAccButton.ForeColor = Color.White;
            deleteAccButton.Location = new Point(33, 299);
            deleteAccButton.Name = "deleteAccButton";
            deleteAccButton.ShadowDecoration.CustomizableEdges = customizableEdges12;
            deleteAccButton.Size = new Size(146, 46);
            deleteAccButton.TabIndex = 3;
            deleteAccButton.Text = "Delete Account";
            deleteAccButton.Click += deleteAccButton_Click;
            // 
            // guna2Button1
            // 
            guna2Button1.BorderRadius = 15;
            guna2Button1.CustomizableEdges = customizableEdges13;
            guna2Button1.DisabledState.BorderColor = Color.DarkGray;
            guna2Button1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2Button1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2Button1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2Button1.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            guna2Button1.ForeColor = Color.White;
            guna2Button1.Location = new Point(33, 210);
            guna2Button1.Name = "guna2Button1";
            guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2Button1.Size = new Size(146, 46);
            guna2Button1.TabIndex = 2;
            guna2Button1.Text = "Change Password";
            // 
            // guna2CirclePictureBox1
            // 
            guna2CirclePictureBox1.Image = Properties.Resources.accIcon;
            guna2CirclePictureBox1.ImageRotate = 0F;
            guna2CirclePictureBox1.Location = new Point(0, 0);
            guna2CirclePictureBox1.Name = "guna2CirclePictureBox1";
            guna2CirclePictureBox1.ShadowDecoration.CustomizableEdges = customizableEdges15;
            guna2CirclePictureBox1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2CirclePictureBox1.Size = new Size(205, 192);
            guna2CirclePictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            guna2CirclePictureBox1.TabIndex = 1;
            guna2CirclePictureBox1.TabStop = false;
            // 
            // borrowTab
            // 
            borrowTab.Controls.Add(borrowButton);
            borrowTab.Controls.Add(borrowDataGridView);
            borrowTab.Location = new Point(184, 4);
            borrowTab.Name = "borrowTab";
            borrowTab.Padding = new Padding(3);
            borrowTab.Size = new Size(712, 492);
            borrowTab.TabIndex = 1;
            borrowTab.Text = "Borrow Book";
            borrowTab.UseVisualStyleBackColor = true;
            // 
            // borrowButton
            // 
            borrowButton.BorderRadius = 15;
            borrowButton.CustomizableEdges = customizableEdges16;
            borrowButton.DisabledState.BorderColor = Color.DarkGray;
            borrowButton.DisabledState.CustomBorderColor = Color.DarkGray;
            borrowButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            borrowButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            borrowButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            borrowButton.ForeColor = Color.White;
            borrowButton.Location = new Point(558, 438);
            borrowButton.Name = "borrowButton";
            borrowButton.ShadowDecoration.CustomizableEdges = customizableEdges17;
            borrowButton.Size = new Size(146, 46);
            borrowButton.TabIndex = 3;
            borrowButton.Text = "Borrow Book";
            borrowButton.Click += borrowButton_Click;
            // 
            // borrowDataGridView
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            borrowDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            borrowDataGridView.BackgroundColor = Color.Silver;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            borrowDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            borrowDataGridView.ColumnHeadersHeight = 10;
            borrowDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            borrowDataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            borrowDataGridView.GridColor = Color.FromArgb(231, 229, 255);
            borrowDataGridView.Location = new Point(18, 17);
            borrowDataGridView.Name = "borrowDataGridView";
            borrowDataGridView.RowHeadersVisible = false;
            borrowDataGridView.Size = new Size(640, 318);
            borrowDataGridView.TabIndex = 0;
            borrowDataGridView.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            borrowDataGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            borrowDataGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            borrowDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            borrowDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            borrowDataGridView.ThemeStyle.BackColor = Color.Silver;
            borrowDataGridView.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            borrowDataGridView.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            borrowDataGridView.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            borrowDataGridView.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            borrowDataGridView.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            borrowDataGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            borrowDataGridView.ThemeStyle.HeaderStyle.Height = 10;
            borrowDataGridView.ThemeStyle.ReadOnly = false;
            borrowDataGridView.ThemeStyle.RowsStyle.BackColor = Color.White;
            borrowDataGridView.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            borrowDataGridView.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            borrowDataGridView.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            borrowDataGridView.ThemeStyle.RowsStyle.Height = 25;
            borrowDataGridView.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            borrowDataGridView.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            // 
            // returnTab
            // 
            returnTab.Controls.Add(returnButton);
            returnTab.Controls.Add(returnDataGridView);
            returnTab.Location = new Point(184, 4);
            returnTab.Name = "returnTab";
            returnTab.Padding = new Padding(3);
            returnTab.Size = new Size(712, 492);
            returnTab.TabIndex = 2;
            returnTab.Text = "Return Book";
            returnTab.UseVisualStyleBackColor = true;
            // 
            // returnButton
            // 
            returnButton.BorderRadius = 15;
            returnButton.CustomizableEdges = customizableEdges18;
            returnButton.DisabledState.BorderColor = Color.DarkGray;
            returnButton.DisabledState.CustomBorderColor = Color.DarkGray;
            returnButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            returnButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            returnButton.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            returnButton.ForeColor = Color.White;
            returnButton.Location = new Point(492, 409);
            returnButton.Name = "returnButton";
            returnButton.ShadowDecoration.CustomizableEdges = customizableEdges19;
            returnButton.Size = new Size(146, 46);
            returnButton.TabIndex = 4;
            returnButton.Text = "Return Book";
            returnButton.Click += returnButton_Click;
            // 
            // returnDataGridView
            // 
            dataGridViewCellStyle4.BackColor = Color.White;
            returnDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            returnDataGridView.BackgroundColor = Color.Silver;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle5.ForeColor = Color.White;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            returnDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            returnDataGridView.ColumnHeadersHeight = 10;
            returnDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = Color.White;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle6.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            returnDataGridView.DefaultCellStyle = dataGridViewCellStyle6;
            returnDataGridView.GridColor = Color.FromArgb(231, 229, 255);
            returnDataGridView.Location = new Point(18, 19);
            returnDataGridView.Name = "returnDataGridView";
            returnDataGridView.RowHeadersVisible = false;
            returnDataGridView.Size = new Size(580, 357);
            returnDataGridView.TabIndex = 1;
            returnDataGridView.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            returnDataGridView.ThemeStyle.AlternatingRowsStyle.Font = null;
            returnDataGridView.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            returnDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            returnDataGridView.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            returnDataGridView.ThemeStyle.BackColor = Color.Silver;
            returnDataGridView.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            returnDataGridView.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            returnDataGridView.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            returnDataGridView.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F);
            returnDataGridView.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            returnDataGridView.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            returnDataGridView.ThemeStyle.HeaderStyle.Height = 10;
            returnDataGridView.ThemeStyle.ReadOnly = false;
            returnDataGridView.ThemeStyle.RowsStyle.BackColor = Color.White;
            returnDataGridView.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            returnDataGridView.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F);
            returnDataGridView.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            returnDataGridView.ThemeStyle.RowsStyle.Height = 25;
            returnDataGridView.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            returnDataGridView.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            returnDataGridView.SelectionChanged += returnSelectChanged;
            // 
            // guna2Elipse1
            // 
            guna2Elipse1.BorderRadius = 20;
            guna2Elipse1.TargetControl = this;
            // 
            // closeButton
            // 
            closeButton.BackColor = Color.White;
            closeButton.BorderRadius = 22;
            closeButton.CustomBorderColor = Color.Transparent;
            closeButton.CustomizableEdges = customizableEdges20;
            closeButton.DisabledState.BorderColor = Color.DarkGray;
            closeButton.DisabledState.CustomBorderColor = Color.DarkGray;
            closeButton.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            closeButton.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            closeButton.FillColor = Color.Red;
            closeButton.FocusedColor = Color.White;
            closeButton.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            closeButton.ForeColor = Color.White;
            closeButton.Location = new Point(849, 4);
            closeButton.Name = "closeButton";
            closeButton.ShadowDecoration.CustomizableEdges = customizableEdges21;
            closeButton.Size = new Size(44, 45);
            closeButton.TabIndex = 16;
            closeButton.Text = "X";
            closeButton.Click += closeButton_Click;
            // 
            // StudentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(900, 500);
            Controls.Add(closeButton);
            Controls.Add(SturdentTabControl);
            FormBorderStyle = FormBorderStyle.None;
            Name = "StudentForm";
            Text = "StudentForm";
            SturdentTabControl.ResumeLayout(false);
            accountTab.ResumeLayout(false);
            accountTab.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)guna2CirclePictureBox1).EndInit();
            borrowTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)borrowDataGridView).EndInit();
            returnTab.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)returnDataGridView).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TabControl SturdentTabControl;
        private TabPage accountTab;
        private TabPage borrowTab;
        private TabPage returnTab;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        protected Guna.UI2.WinForms.Guna2CirclePictureBox guna2CirclePictureBox1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Button deleteAccButton;
        private Guna.UI2.WinForms.Guna2TextBox nameTextBox;
        private Guna.UI2.WinForms.Guna2TextBox emailTextBox;
        private Guna.UI2.WinForms.Guna2TextBox surnameTextBox;
        private Guna.UI2.WinForms.Guna2DateTimePicker birthDateTimePicker;
        private Guna.UI2.WinForms.Guna2HtmlLabel emailLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel surnameLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel nameLabel;
        private Guna.UI2.WinForms.Guna2Button saveButton;
        private Guna.UI2.WinForms.Guna2Button closeButton;
        private Guna.UI2.WinForms.Guna2HtmlLabel idLabel;
        private Guna.UI2.WinForms.Guna2HtmlLabel birthDateLabel;
        private Guna.UI2.WinForms.Guna2DataGridView borrowDataGridView;
        private Guna.UI2.WinForms.Guna2Button borrowButton;
        private Guna.UI2.WinForms.Guna2Button returnButton;
        private Guna.UI2.WinForms.Guna2DataGridView returnDataGridView;
    }
}