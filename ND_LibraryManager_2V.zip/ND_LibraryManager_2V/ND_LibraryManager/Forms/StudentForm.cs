﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace ND_LibraryManager.Forms
{
    public partial class StudentForm : Form
    {
        private Library library;
        private Student currentStudent;

        public StudentForm(Library library, Student student)
        {
            InitializeComponent();
            this.library = library;
            this.currentStudent = student;
            LoadAccountInfo();
        }
        private void tabIndexChenged(object sender, EventArgs e)
        {
            LoadAccountInfo();
            loadBooks();
            loadBooksToReturn(); 
        }
        private void closeButton_Click(object sender, EventArgs e)
        {
            //library.SaveDataToFiles();
            this.Close();
        }

        //Account
        private void LoadAccountInfo()
        {
            idLabel.Text = currentStudent.ID.ToString();
            //txtPassword.Text = currentStudent.Password; 
            nameTextBox.Text = currentStudent.Name;
            surnameTextBox.Text = currentStudent.Surname;
            emailTextBox.Text = currentStudent.Email;
            birthDateTimePicker.Value = currentStudent.BirthDate;

            saveButton.Enabled = false;
        }
        private void saveButton_Click(object sender, EventArgs e)
        {
            currentStudent.Email = emailTextBox.Text;
            currentStudent.Name = nameTextBox.Text;
            currentStudent.Surname = surnameTextBox.Text;
            currentStudent.BirthDate = birthDateTimePicker.Value;

            library.UpdateUser(currentStudent);
            MessageBox.Show("Information succesfully updated!");

            saveButton.Enabled = false;
        }
        private void userInfoChanged(object sender, EventArgs e)
        {
            saveButton.Enabled = true;
        }
        private void deleteAccButton_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to permanently remove this account?", "Confirm Deletion", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                library.RemoveEntity<Student>(currentStudent.ID);
                MessageBox.Show("Account deleted succesfully.");
                this.Close();
            }
            else
            {
                MessageBox.Show("Error ocured", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //BorrowBooks
        private void loadBooks()
        {
            borrowDataGridView.DataSource = null;
            borrowDataGridView.DataSource ??= library.GetBooks();//??=
            borrowDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            borrowDataGridView.ColumnHeadersHeight = 30;
            borrowDataGridView.RowTemplate.Height = 30;
            borrowDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            borrowDataGridView.MultiSelect = true;
            borrowDataGridView.ReadOnly = true;

            borrowDataGridView.Columns["Title"].HeaderText = "Title";
            borrowDataGridView.Columns["Author"].HeaderText = "Author";
            borrowDataGridView.Columns["ISBN"].HeaderText = "ISBN";
            borrowDataGridView.Columns["PublishDate"].HeaderText = "Publish Date";
            borrowDataGridView.Columns["Quantity"].HeaderText = "Quantity";
            borrowDataGridView.Columns["BorrowedBooks"].Visible = false;

        }

        private void borrowButton_Click(object sender, EventArgs e)
        {
            var selectedBookIds = borrowDataGridView.SelectedRows
                .OfType<DataGridViewRow>()
                .Select(row => ((Book)row.DataBoundItem).ID) 
                .ToArray();

            library.BorrowBooks(currentStudent.ID, selectedBookIds);
            loadBooks();
            loadBooksToReturn();
        }
        //ReturnBooks
        private void loadBooksToReturn()
        {
            var borrowedBooks = library.GetBorrowedBooksForStudent(currentStudent.ID)
                .Select(bb => new  // for table to only show necessary Columns
                {
                    BookId = bb.BookID,
                    Title = bb.Book.Title,
                    Author = bb.Book.Author,
                    BorrowDate = bb.BorrowDate,
                    ReturnDate = bb.ReturnDate
                })
                .OrderBy(bb => bb.ReturnDate.HasValue) 
                .ThenBy(bb => bb.BorrowDate)
                .ToList();
            returnDataGridView.DataSource = null;
            returnDataGridView.DataSource ??= borrowedBooks; 
            
            returnDataGridView.Columns["BookID"].Visible = false;
            returnDataGridView.Columns["BorrowDate"].HeaderText = "Borrow Date";
            returnDataGridView.Columns["ReturnDate"].HeaderText = "Return Date";

            returnDataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            returnDataGridView.ColumnHeadersHeight = 30;
            returnDataGridView.RowTemplate.Height = 30;
            returnDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            returnDataGridView.MultiSelect = true;
            returnDataGridView.ReadOnly = true;
        }
        private void returnButton_Click(object sender, EventArgs e)
        {
            if (returnDataGridView.SelectedRows.Count > 0)
            {
                var selectedBookIds = returnDataGridView.SelectedRows
                 .OfType<DataGridViewRow>()
                 .Select(row => (int)row.Cells["BookID"].Value)
                 .ToArray();

                string result = library.ReturnBooks(currentStudent.ID, selectedBookIds);
                MessageBox.Show(result);

                loadBooksToReturn();
            }
            else
            {
                MessageBox.Show("Prašome pasirinkti knygą, kurią norite grąžinti.");
            }
        }



        private void returnSelectChanged(object sender, EventArgs e)
        {

        }

        
    }
}

