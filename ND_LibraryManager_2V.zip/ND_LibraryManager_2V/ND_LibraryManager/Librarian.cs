﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ND_LibraryManager
{
    //[XmlInclude(typeof(Student))]
    //[XmlInclude(typeof(Librarian))]
    public class Librarian : LibraryUser
    {
        public string PhoneNum {  get; set; }
        public string Address { get; set; }
        
        public Librarian() { }
        public Librarian(string name, string surname, string email, int id, string password, DateTime birthDate, string phoneNum, string address)
            : base(name, surname, email, id, password, birthDate)
        {
            this.PhoneNum = phoneNum;
            this.Address = address;
        }
    }
}
