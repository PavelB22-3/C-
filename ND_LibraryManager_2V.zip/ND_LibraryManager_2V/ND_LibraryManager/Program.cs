using ND_LibraryManager.Forms;

namespace ND_LibraryManager
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        ///  Tasks1:
        ///  Sukurete ir pritaikete savo sasaja (interface) (0.5 t.) - IBorrowable
        ///  Naudojate 'switch' su 'when' raktazodziu (0.5 t.) - LoginForm
        ///  Naudojate uzdaryta ('sealed') arba daline ('partial') klase (0.5 t.) - Library class
        ///  Naudojate abstrakcia klase (0.5 t.) - LibraryUser class
        ///  Naudojamos duomenu strukturos is System.Collections arba System.Collections.Generic (1 t.) - Lists
        ///  Naudojamas operatorius 'is' (0.5 t.) 
        ///  Naudojamas raktazodis 'params' (0.5 t.) - Library
        ///  Realizuota inicializacija naudojant 'out' argumentus (1 t.) - Login
        ///  Naudojami operatoriai ?. ?[] ?? arba ??= (0.5 t.) - LibriarianForm,StudentForm
        ///  Naudojamas sablonu atitikimas(1 t.) - Library(done in part with is operator)
        ///  Teisingai atlikote implementacija IEquatable<T> (0.5 t.) - Book
        ///  total: 7 t.
        /// Tasks2:
        /// Naudojate savo projekte duomenu baze ir Entity Framework. (3 t.) - Entity Fromework 8v., EntyFramworkTools8v, EntityFrameworkMySQL8v
        /// Naudojate LINQ (1 t.) - Library
        /// Suk?r?te savo bendr?j? (generic) pl?timo metod? (1 t.) - RemoveEntity<T> in Library
        /// Yra blokai 'try' 'catch' vietose, kur gali ivykti klaida (1 t.) - Library
        /// Sukurete ir panaudojote savo isimties tipus (1 t.) - ValidationException
        /// total: 7 t.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.

            Library library = new Library();

            ApplicationConfiguration.Initialize();
            Application.Run(new LoginForm(library));
        }
    }
}