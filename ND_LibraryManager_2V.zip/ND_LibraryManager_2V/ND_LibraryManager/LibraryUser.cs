﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ND_LibraryManager
{
    [XmlInclude(typeof(Student))]
    [XmlInclude(typeof(Librarian))]
    public abstract class LibraryUser
    {
        public int ID { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public DateTime BirthDate { get; set; }
        public string UserType { get; set; }

        public LibraryUser() { }
        public LibraryUser(string name, string surname, string email, int id, string password, DateTime birthDate)
        {
            this.Name = name;
            this.Surname = surname;
            this.Email = email;
            this.ID = id;
            this.Password = password;       
            this.BirthDate = birthDate;
        }

    }
}
