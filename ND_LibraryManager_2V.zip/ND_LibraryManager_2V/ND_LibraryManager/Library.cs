﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ND_LibraryManager
{
    public sealed class Library // sealed
    {

        public Library()
        {
        }

        /*Files(before database)
        private void LoadDataFromFiles()
        {
            books = FileStorage.LoadBooksFromFile("books.xml");
            users = FileStorage.LoadUsersFromFile("users.xml");
        }

        public void SaveDataToFiles()
        {
            FileStorage.SaveBooksToFile("books.xml", books);
            FileStorage.SaveUsersToFile("users.xml", users);
        }

        public List<Book> GetBorrorwedBooks(Student student)
        {
            var borrowedBooksByStudent = borrowedBooks
            .Where(b => b.Value == student)
            .Select(b => b.Key)
            .ToList();

            return borrowedBooksByStudent;
        }*/

        public int GenerateUniqueId(bool isLibrarian)
        {
            List<int> existingIds;
            using (var context = new AppDbContext())
            {
                existingIds = context.Students
                .Select(s => s.ID)
                .Union(context.Librarians.Select(l => l.ID))
                .ToList();
            }
            Random random = new Random();
            int id;

            do
            {
                id = random.Next(10000, 100000);
            } while (existingIds.Contains(id) || (isLibrarian && id / 10000 != 1) || (!isLibrarian && id / 10000 == 1));

            return id;
        }

        public LibraryUser Login(int id, string password)
        {
            try
            {
                using (var context = new AppDbContext())
                {
                    var student = context.Students
                        .FirstOrDefault(s => s.ID == id && s.Password == password);
                    if (student != null)
                    {
                        return student;
                    }

                    var librarian = context.Librarians
                        .FirstOrDefault(l => l.ID == id && l.Password == password);
                    if (librarian != null)
                    {
                        return librarian;
                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return null;
        }

        public List<Book> GetBooks()
        {
            using (var context = new AppDbContext())
            {
                var books = context.Books.ToList();
                return books;
            }
        }

        public List<LibraryUser> GetUsers()//if decided to let admin modify another admin
        {
            return null;
        }

        public List<Student> GetStudents()
        {
            using (var context = new AppDbContext())
            {
                var students = context.Students.ToList();
                return students;
            }
        }

        public void UpdateUser(LibraryUser updatedUser)
        {         
            using (var context = new AppDbContext())
            {
                if (updatedUser is Student updatedStudent)
                {
                    var student = context.Students.FirstOrDefault(s => s.ID == updatedUser.ID);
                    student.Name = updatedStudent.Name;
                    student.Surname = updatedStudent.Surname;
                    student.Email = updatedStudent.Email;
                    student.Password = updatedStudent.Password;
                    student.BirthDate = updatedStudent.BirthDate;                 
                }
                else if (updatedUser is Librarian updatedLibrarian)
                {
                    var librarian = context.Librarians.FirstOrDefault(s => s.ID == updatedUser.ID);
                    librarian.Name = updatedLibrarian.Name;
                    librarian.Surname = updatedLibrarian.Surname;
                    librarian.Email = updatedLibrarian.Email;
                    librarian.Password = updatedLibrarian.Password;
                    librarian.BirthDate = updatedLibrarian.BirthDate;
                    librarian.Address = updatedLibrarian.Address;
                    librarian.PhoneNum = updatedLibrarian.PhoneNum;
                }
                context.SaveChanges();
            }
        }

        public void UpdateBook(Book updatedBook)
        {
            using (var context = new AppDbContext())
            {
                var book = context.Books.FirstOrDefault(b => b.ID == updatedBook.ID);
                if (book != null)
                {
                    book.ISBN = updatedBook.ISBN;
                    book.Author = updatedBook.Author;
                    book.Title = updatedBook.Title;
                    book.PublishDate = updatedBook.PublishDate;
                    book.Quantity = updatedBook.Quantity;
                    context.SaveChanges();
                }
            }
        }

        public void AddBook(Book book)
        {
            using (var context = new AppDbContext())
            {
                context.Books.Add(book);
                context.SaveChanges();
            }
        }

        public void AddUser(LibraryUser user)
        {
            using (var context = new AppDbContext())
            {
                if(user is Student student) // is
                {
                    context.Students.Add(student);
                }
                else if (user is Librarian librarian)
                {
                    context.Librarians.Add(librarian);
                }             
                context.SaveChanges();
            }
        }

        public void RemoveEntity<T>(int id) where T : class // generic metodas
        {
            using (var context = new AppDbContext())
            {
                var entity = context.Set<T>().Find(id); 
                if (entity != null)
                {
                    context.Set<T>().Remove(entity); 
                    context.SaveChanges(); 
                }
            }
        }
       
        public List<BorrowedBook> GetBorrowedBooksForStudent(int studentId)
        {
            using (var context = new AppDbContext())
            {
                var borrowedBooks = context.BorrowedBooks
                    .Include(bb => bb.Book)
                    .Where(bb => bb.StudentID == studentId)
                    .ToList();
                return borrowedBooks;
            }
        }

        public void BorrowBooks(int studentId, params int[] bookIds)//params
        {
            try
            {
                using (var context = new AppDbContext())
                {
                    var student = context.Students.FirstOrDefault(s => s.ID == studentId);
                    if (student == null)
                    {
                        throw new ValidationException("Student not found.");
                    }

                    int currentBorrowedCount = context.BorrowedBooks.Count(bb => bb.StudentID == studentId && bb.ReturnDate == null);
                    if (currentBorrowedCount + bookIds.Length > 3)
                    {
                        throw new ValidationException("You can't borrow more than 3 books at once.");
                    }

                    foreach (var bookId in bookIds)
                    {
                        var existingBorrow = context.BorrowedBooks
                            .FirstOrDefault(bb => bb.StudentID == studentId && bb.BookID == bookId && bb.ReturnDate == null);
                        if (existingBorrow != null)
                        {
                            throw new ValidationException("You can't borrow 2 identical books.");
                        }

                        var book = context.Books.FirstOrDefault(b => b.ID == bookId);
                        if (book == null)
                        {
                            throw new ValidationException("Book does not exist.");
                        }
                        else if (!book.Borrow())
                        {
                            throw new ValidationException($"Book '{book.Title}' is not available.");
                        }

                        var borrowedBook = new BorrowedBook
                        {
                            StudentID = studentId,
                            BookID = bookId,
                            BorrowDate = DateTime.Now
                        };
                        context.BorrowedBooks.Add(borrowedBook);
                    }
                    context.SaveChanges();
                    MessageBox.Show("Book(-s) successfully borrowed.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information); ;
                }
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public string ReturnBooks(int studentId, params int[] bookIds)
        {
            using (var context = new AppDbContext())
            {
                var student = context.Students.FirstOrDefault(s => s.ID == studentId);
                if (student == null)
                {
                    return "Student not found.";
                }

                foreach (var bookId in bookIds)
                {
                    var borrowedBook = context.BorrowedBooks
                        .FirstOrDefault(bb => bb.BookID == bookId && bb.StudentID == studentId && bb.ReturnDate == null);

                    if (borrowedBook == null)
                    {
                        return $"Book does not found or already have been returned.";
                    }

                    var book = context.Books.FirstOrDefault(b => b.ID == bookId);
                    if (book != null)
                    {
                        book.Return();
                    }
                    borrowedBook.ReturnDate = DateTime.Now;
                }

                context.SaveChanges();
                return "Book(-s) succsesfully returned.";
            }
        }
    }
}


