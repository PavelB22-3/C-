﻿using Microsoft.EntityFrameworkCore;
using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ND_LibraryManager
{
    public class AppDbContext : DbContext
    {
        public DbSet<Librarian> Librarians { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<BorrowedBook> BorrowedBooks { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(
                "Server=localhost;Database=mylibrary;User=root;Password=;",
                new MySqlServerVersion(new Version(8, 0, 31)) // MySQL versija
            );
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<LibraryUser>()
                .HasDiscriminator<string>("UserType")
                .HasValue<LibraryUser>("LibraryUser")
                .HasValue<Student>("Student")
                .HasValue<Librarian>("Librarian");

            // Santykiai tarp BorrowedBook ir Book
            modelBuilder.Entity<BorrowedBook>()
                .HasOne(bb => bb.Book)
                .WithMany(b => b.BorrowedBooks)
                .HasForeignKey(bb => bb.BookID);

            // Santykiai tarp BorrowedBook ir Student
            modelBuilder.Entity<BorrowedBook>()
                .HasOne(bb => bb.Student)
                .WithMany(s => s.BorrowedBooks) 
                .HasForeignKey(bb => bb.StudentID)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Book>(entity =>
            {
                entity.Property(b => b.Title)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(b => b.Author)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(b => b.ISBN)
                    .IsRequired()
                    .HasMaxLength(13);

                entity.Property(b => b.PublishDate)
                    .IsRequired();

                entity.Property(b => b.Quantity)
                    .IsRequired();
            });
        }

    }
}
