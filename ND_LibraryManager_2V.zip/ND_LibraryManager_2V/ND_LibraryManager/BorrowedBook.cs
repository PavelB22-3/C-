﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ND_LibraryManager
{
    public class BorrowedBook
    {
        public int ID { get; set; }
        public int BookID { get; set; }
        public Book Book { get; set; }

        public int StudentID { get; set; }
        public Student Student { get; set; }

        public DateTime BorrowDate { get; set; }
        public DateTime? ReturnDate { get; set; }



    }
}
