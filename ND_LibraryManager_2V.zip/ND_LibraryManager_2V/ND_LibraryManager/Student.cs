﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ND_LibraryManager
{
    //[XmlInclude(typeof(Student))]
    //[XmlInclude(typeof(Librarian))]
    public class Student : LibraryUser
    {
        public ICollection<BorrowedBook> BorrowedBooks { get; set; }

        public Student() { }
        public Student(string name, string surname, string email, int id, string password, DateTime birthDate)
            : base(name, surname, email, id, password, birthDate)
        {

        }
    }
}
