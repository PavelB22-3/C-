﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Text.Json;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace ND_LibraryManager
{
    public static class FileStorage
    {
        static FileStorage()//static constructor
        {
            if (!File.Exists("books.xml"))
            {
                using (File.Create("books.xml")) { } 
            }
            if (!File.Exists("users.xml"))
            {
                using (File.Create("users.xml")) { }
            }
        }
        public static List<Book> LoadBooksFromFile(string filePath)
        {
            if (!File.Exists(filePath))
                return new List<Book>();

            XmlSerializer serializer = new XmlSerializer(typeof(List<Book>));
            using (StreamReader reader = new StreamReader(filePath))
            {
                return (List<Book>)serializer.Deserialize(reader);
            }
        }
        public static void SaveBooksToFile(string filePath, List<Book> books)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<Book>));
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                serializer.Serialize(writer, books);
            }
        }

        public static List<LibraryUser> LoadUsersFromFile(string filePath)
        {
            if (!File.Exists(filePath))
                return new List<LibraryUser>();

            XmlSerializer serializer = new XmlSerializer(typeof(List<LibraryUser>), new Type[] { typeof(Student), typeof(Librarian) });
            using (StreamReader reader = new StreamReader(filePath))
            {
                return (List<LibraryUser>)serializer.Deserialize(reader);
            }
        }

        public static void SaveUsersToFile(string filePath, List<LibraryUser> users)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(List<LibraryUser>), new Type[] { typeof(Student), typeof(Librarian) });
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                serializer.Serialize(writer, users);
            }
        }
    }
}

*/